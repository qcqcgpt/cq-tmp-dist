"""回归测试：2026-08-23 全系统审计修复（实盘关键路径）。"""
import pandas as pd

from datahub.hub import DataHub
from strategy.dsl import DslStrategy


class TestDslSpecParams:
    """DSL 策略 spec 自带的 top_n/rebalance_days 不得被 schema 默认值 5/5 覆盖。"""

    def _spec(self, top_n):
        return {"id": "custom_t", "name": "测试", "universe_prefixes": [],
                "factors": [{"name": "momentum", "window": 20, "weight": 1.0, "direction": "desc"}],
                "filters": [], "top_n": top_n, "rebalance_days": 3, "invest_pct": 0.8}

    def test_resolve_params_defaults_from_spec(self):
        st = DslStrategy(self._spec(3))
        p = st.resolve_params({})
        assert p["top_n"] == 3 and p["rebalance_days"] == 3

    def test_explicit_overrides_still_win(self):
        st = DslStrategy(self._spec(3))
        p = st.resolve_params({"top_n": 7})
        assert p["top_n"] == 7

    def test_resolve_params_clamps_out_of_range(self):
        st = DslStrategy(self._spec(3))
        p = st.resolve_params({"top_n": 100})
        assert p["top_n"] == 10  # 钳到 schema max


class _FakeSource:
    """is_trading_day 测试源：可控制数据截止日与刷新行为。"""

    def __init__(self, last_day, today):
        self._last_day = last_day
        self._today = today
        self.refresh_calls = 0

    def list_symbols(self):
        return [("600519.SH", "茅台")]

    def daily_bars(self, symbol, start=None, end=None):
        idx = pd.bdate_range("2024-01-01", "2024-01-05").append(pd.DatetimeIndex([self._last_day]))
        return pd.DataFrame({"close": 1.0}, index=idx)

    def refresh_symbol(self, symbol):
        self.refresh_calls += 1
        self._last_day = self._today  # 刷新后数据覆盖到今天


class TestTradingDaySelfHeal:
    """盘前读到旧数据误判非交易日时：不缓存 False，强制刷新后应能自愈。"""

    def test_stale_data_triggers_refresh_and_recheck(self):
        today = pd.Timestamp("2024-01-08").date()  # 周一
        src = _FakeSource(pd.Timestamp("2024-01-05").date(), today)  # 数据停在上周五
        hub = DataHub(src)
        assert hub.is_trading_day(today) is True, "强制刷新后应识别交易日"
        assert src.refresh_calls == 1
        assert hub.is_trading_day(today) is True  # True 结果被缓存

    def test_false_not_cached(self):
        today = pd.Timestamp("2024-01-08").date()
        src = _FakeSource(pd.Timestamp("2024-01-05").date(), today)
        src.refresh_symbol = lambda s: None  # 刷新也拿不到今天（真节假日/停牌）
        hub = DataHub(src)
        assert hub.is_trading_day(today) is False
        assert today not in hub._trading_day_cache, "False 结果不得缓存（防全天锁死）"

    def test_snapshot_fallback_marks_trading_day(self):
        """日线不含当日 forming bar（datafeed 盘中常态）时：快照时间戳为当日 → 判交易日。"""
        today = pd.Timestamp("2024-01-08").date()
        src = _FakeSource(pd.Timestamp("2024-01-05").date(), today)
        src.refresh_symbol = lambda s: None                       # 日线刷新也拿不到今天
        src.snapshot = lambda: [{"ts": "2024-01-08T10:00:00"}]    # 但快照已是当日
        hub = DataHub(src)
        assert hub.is_trading_day(today) is True

    def test_snapshot_stale_still_false(self):
        """快照停留在上一交易日（真节假日）→ 仍判 False 且不缓存。"""
        today = pd.Timestamp("2024-01-08").date()
        src = _FakeSource(pd.Timestamp("2024-01-05").date(), today)
        src.refresh_symbol = lambda s: None
        src.snapshot = lambda: [{"ts": "2024-01-05T15:00:00"}]    # 快照停在上周五
        hub = DataHub(src)
        assert hub.is_trading_day(today) is False
        assert today not in hub._trading_day_cache

    def test_snapshot_failure_falls_back_false(self):
        """快照接口异常 → 保守 False，不报错不缓存。"""
        today = pd.Timestamp("2024-01-08").date()
        src = _FakeSource(pd.Timestamp("2024-01-05").date(), today)
        src.refresh_symbol = lambda s: None

        def _boom():
            raise RuntimeError("tunnel down")
        src.snapshot = _boom
        hub = DataHub(src)
        assert hub.is_trading_day(today) is False


# ============ 2026-08-22 二批审计修复（API/运维层 + AI 向导） ============


class TestReportPriceFallback:
    """取不到行情的持仓按成本价兜底：浮盈显示 0，不出现 -100% 假数据；total_asset=0 不除零。"""

    class _QE:
        def get_price(self, symbol):
            return None  # 行情缺失

    @staticmethod
    def _exec(total_asset, cash, positions):
        class _Exec:
            def account(self):
                return {"total_asset": total_asset, "cash": cash}

            def deals(self):
                return []

            def positions(self):
                return positions

        return _Exec()

    def test_missing_price_uses_avg_cost(self):
        from report import daily_report

        exec_ = self._exec(100_000.0, 50_000.0,
                           [{"symbol": "600519.SH", "qty": 100, "avg_cost": 500.0}])
        rep = daily_report(exec_, self._QE(), lambda s: s)
        row = rep["positions"][0]
        assert row["price"] == 500.0 and row["pnl"] == 0.0 and row["pnl_pct"] == 0.0

    def test_zero_total_asset_no_zero_division(self):
        from report import daily_report

        rep = daily_report(self._exec(0.0, 0.0, []), self._QE(), lambda s: s)
        assert rep["account"]["position_pct"] == 0.0
        assert "仓位 0.0%" in rep["text"]


class TestCustomStoreRobustness:
    """存储文件为非列表 JSON 时按空处理；非字符串 id 走 ValueError（API 层映射 400）。"""

    def test_dict_content_loads_as_empty(self, tmp_path, monkeypatch):
        from strategy import custom_store

        f = tmp_path / "custom.json"
        f.write_text('{"broken": true}', encoding="utf-8")
        monkeypatch.setattr(custom_store, "_STORE", f)
        monkeypatch.setattr(custom_store, "_cache", {})
        monkeypatch.setattr(custom_store, "_loaded", False)
        assert custom_store.list_custom() == []

    def test_non_str_id_raises_value_error(self, tmp_path, monkeypatch):
        import pytest

        from strategy import custom_store

        monkeypatch.setattr(custom_store, "_STORE", tmp_path / "custom.json")
        monkeypatch.setattr(custom_store, "_cache", {})
        monkeypatch.setattr(custom_store, "_loaded", False)
        with pytest.raises(ValueError):
            custom_store.save_custom({"id": None, "name": "x", "factors": []})
        with pytest.raises(ValueError):
            custom_store.save_custom({"id": 123, "name": "x", "factors": []})

    def test_save_is_atomic_and_reloadable(self, tmp_path, monkeypatch):
        from strategy import custom_store

        f = tmp_path / "custom.json"
        monkeypatch.setattr(custom_store, "_STORE", f)
        monkeypatch.setattr(custom_store, "_cache", {})
        monkeypatch.setattr(custom_store, "_loaded", False)
        spec = {"id": "t_atomic", "name": "原子写",
                "factors": [{"name": "momentum", "window": 20, "weight": 0.5, "direction": "desc"}],
                "top_n": 3, "rebalance_days": 5}
        custom_store.save_custom(spec)
        assert not (tmp_path / "custom.tmp").exists(), "临时文件应已被原子替换"
        monkeypatch.setattr(custom_store, "_cache", {})
        monkeypatch.setattr(custom_store, "_loaded", False)
        assert [s.id for s in custom_store.list_custom()] == ["t_atomic"]


class TestScreenerStaleAndOutage:
    """长期停牌的陈旧数据剔除；全部票拉取失败抛 RuntimeError（API 层映射 502）。"""

    @staticmethod
    def _bars(last_date: str, n: int = 30):
        bars = [{"date": "2024-01-02", "close": 100.0 + i, "volume": 1e6}
                for i in range(n - 1)]
        bars.append({"date": last_date, "close": 130.0, "volume": 1e6})
        return bars

    def test_stale_bars_skipped(self, monkeypatch):
        import screener

        def fake_get(base, path, timeout=15.0, token="", **params):
            if path == "/md/instrument":
                return [{"symbol": "600519.SH", "name": "茅台"}]
            return {"bars": self._bars("2020-01-03")}  # 最后一根停在 2020 年

        monkeypatch.setattr(screener, "_http_get", fake_get)
        assert screener.screen("http://x", watchlist=["600519.SH"]) == []

    def test_fresh_bars_kept(self, monkeypatch):
        import screener

        today = pd.Timestamp.now().strftime("%Y-%m-%d")

        def fake_get(base, path, timeout=15.0, token="", **params):
            if path == "/md/instrument":
                return [{"symbol": "600519.SH", "name": "茅台"}]
            return {"bars": self._bars(today)}

        monkeypatch.setattr(screener, "_http_get", fake_get)
        rows = screener.screen("http://x", watchlist=["600519.SH"])
        assert len(rows) == 1 and rows[0]["symbol"] == "600519.SH"

    def test_all_failed_raises_runtime_error(self, monkeypatch):
        import pytest

        import screener

        def fake_get(base, path, timeout=15.0, token="", **params):
            if path == "/md/instrument":
                return []
            raise OSError("connection refused")

        monkeypatch.setattr(screener, "_http_get", fake_get)
        with pytest.raises(RuntimeError, match="行情服务不可达"):
            screener.screen("http://x", watchlist=["600519.SH", "000001.SZ"])


class TestBuildSpecInvestPct:
    """百分数仅在仓位语境作目标仓位："年化 20%" 收益描述不误判；"X成" 兼容保留。"""

    def test_return_pct_not_treated_as_position(self):
        from wizard.engine import build_spec_local

        spec, _ = build_spec_local("做一个动量策略，目标年化 20% 以上")
        assert spec["invest_pct"] == 0.95  # 默认值不被 "年化 20%" 覆盖

    def test_position_context_pct(self):
        from wizard.engine import build_spec_local

        spec, _ = build_spec_local("动量策略，仓位控制在 70%")
        assert spec["invest_pct"] == 0.7

    def test_cheng_still_works(self):
        from wizard.engine import build_spec_local

        spec, _ = build_spec_local("动量策略，7成仓")
        assert spec["invest_pct"] == 0.7

    def test_mancang_not_overridden_by_return_pct(self):
        from wizard.engine import build_spec_local

        spec, _ = build_spec_local("激进满仓的动量策略，年化 20% 以上")
        assert spec["invest_pct"] == 1.0


class TestOptimizeReproducible:
    """网格超限随机采样用固定种子：同一 spec 两次寻优抽样一致。"""

    def test_param_grid_sampling_deterministic(self):
        from wizard.optimize import _param_grid

        a = _param_grid(2, 24)  # 4×4×3×3=144 > 24 → 触发抽样
        b = _param_grid(2, 24)
        assert len(a) == 24 and a == b


class TestEventBusThreadSafe:
    """订阅在 async 上下文、发布在线程池线程：经 call_soon_threadsafe 安全入队。"""

    def test_publish_from_worker_thread(self):
        import asyncio
        import threading

        from paper.events import EventBus

        async def main():
            bus = EventBus()
            q = bus.subscribe()
            t = threading.Thread(target=bus.publish, args=({"type": "auto", "data": {}},))
            t.start()
            event = await asyncio.wait_for(q.get(), timeout=2.0)
            t.join()
            return event

        assert asyncio.run(main())["type"] == "auto"

    def test_publish_without_loop_falls_back(self):
        from paper.events import EventBus

        bus = EventBus()
        q = bus.subscribe()  # 非 async 上下文：不记录 loop，退回直接 put_nowait
        bus.publish({"type": "x"})
        assert q.get_nowait()["type"] == "x"
