"""策略与 AI 能力升级单测：

- 新因子（reversal / vol_cone / volume_trend）方向语义与取值范围
- wizard 本地规则识别新因子关键词
- optimize 网格计数、提前返回、结果结构
- composite 权重加权正确性、custom store 存取回归
- report narrative 无 llm 配置 / llm 故障时静默回退
"""
import numpy as np
import pandas as pd
import pytest

from strategy.dsl import FACTOR_FUNCS, validate_spec


def _panel(data: dict, periods: int) -> pd.DataFrame:
    dates = pd.bdate_range("2024-01-02", periods=periods)
    return pd.DataFrame(data, index=dates)


# ---------- 新因子方向语义 ----------

class TestNewFactors:
    def test_reversal_sign(self):
        """单调上涨 → reversal < 0；单调下跌 → reversal > 0。"""
        close = _panel({"UP": np.linspace(10, 20, 60), "DOWN": np.linspace(20, 10, 60)}, 60)
        volume = _panel({"UP": 1e6, "DOWN": 1e6}, 60)
        rev = FACTOR_FUNCS["reversal"](close, volume, 5)
        assert rev["UP"].iloc[-1] < 0
        assert rev["DOWN"].iloc[-1] > 0

    def test_volume_trend_sign(self):
        """量能单调放大 → 5 日均量 > 20 日均量 → volume_trend > 0；反之 < 0。"""
        close = _panel({"UPV": 10.0, "DOWNV": 10.0}, 60)
        volume = _panel({"UPV": np.linspace(1e5, 1e6, 60),
                         "DOWNV": np.linspace(1e6, 1e5, 60)}, 60)
        vt = FACTOR_FUNCS["volume_trend"](close, volume, 5)
        assert vt["UPV"].iloc[-1] > 0
        assert vt["DOWNV"].iloc[-1] < 0

    def test_vol_cone_range_and_order(self):
        """分位数取值 0~1；末段平静的序列分位数应低于末段剧烈波动的序列。"""
        n = 160
        rng = np.random.default_rng(7)
        calm = 100 * np.cumprod(1 + rng.choice([-0.05, 0.05], size=n))
        calm[-20:] = calm[-21] * np.cumprod(1 + rng.normal(0, 0.0005, 20))  # 末段平静
        wild = 100 * np.cumprod(1 + rng.choice([-0.05, 0.05], size=n))
        wild[-20:] = wild[-21] * np.cumprod(1 + rng.choice([-0.08, 0.08], size=20))  # 末段更剧烈
        close = _panel({"CALM": calm, "WILD": wild}, n)
        volume = _panel({"CALM": 1e6, "WILD": 1e6}, n)
        cone = FACTOR_FUNCS["vol_cone"](close, volume, 20)
        calm_v, wild_v = cone["CALM"].iloc[-1], cone["WILD"].iloc[-1]
        assert 0.0 <= calm_v <= 1.0
        assert 0.0 <= wild_v <= 1.0
        assert calm_v < wild_v

    def test_validate_spec_accepts_new_factors(self):
        for name in ("reversal", "vol_cone", "volume_trend"):
            spec = {"id": "t_new_factor", "name": "t",
                    "factors": [{"name": name, "window": 20, "weight": 0.5}],
                    "top_n": 3, "rebalance_days": 5}
            assert validate_spec(spec) == [], f"{name} 应通过校验"

    def test_local_rules_know_new_factor_keywords(self):
        from wizard.engine import build_spec_local

        spec, _ = build_spec_local("做一个量能趋势增强的反转策略，叠加低波锥过滤")
        names = {f["name"] for f in spec["factors"]}
        assert {"volume_trend", "reversal", "vol_cone"} <= names


# ---------- optimize 网格与超时 ----------

_OPT_SPEC = {
    "id": "t_opt", "name": "寻优测试",
    "factors": [{"name": "momentum", "window": 20, "weight": 0.6, "direction": "desc"}],
    "top_n": 3, "rebalance_days": 5,
}


def _market(n: int = 260):
    rng = np.random.default_rng(11)
    symbols = ["600519.SH", "000001.SZ", "300750.SZ", "688981.SH", "601318.SH"]
    dates = pd.bdate_range("2023-06-01", periods=n)
    close = pd.DataFrame({s: 100 * np.cumprod(1 + rng.normal(0, 0.02, n)) for s in symbols},
                         index=dates)
    volume = pd.DataFrame({s: rng.uniform(5e5, 2e6, n) for s in symbols}, index=dates)
    return close, volume


class TestOptimize:
    def test_grid_capped_at_24_and_result_shape(self):
        """单因子完整网格 4×3×3=36 > 24 → 随机采样，tried 恰为 24。"""
        from backtest import run_backtest
        from wizard.optimize import optimize

        close, volume = _market()
        out = optimize(_OPT_SPEC, close=close, volume=volume, run_backtest_fn=run_backtest)
        assert out["tried"] == 24
        assert out["best_spec"]["top_n"] in (3, 5, 8)
        assert out["best_spec"]["rebalance_days"] in (5, 10, 20)
        assert out["best_spec"]["factors"][0]["window"] in (10, 20, 40, 60)
        assert {"annual_return", "sharpe", "max_drawdown"} <= set(out["train_metrics"])
        assert "sharpe" in out["oos_metrics"]
        assert out["overfit_grade"] in ("好", "中", "差")

    def test_time_budget_early_return(self):
        """time_budget_sec=0：跑完第一组即提前返回，不跑满网格。"""
        from backtest import run_backtest
        from wizard.optimize import optimize

        close, volume = _market()
        out = optimize(_OPT_SPEC, close=close, volume=volume,
                       run_backtest_fn=run_backtest, time_budget_sec=0.0)
        assert 1 <= out["tried"] < 24

    def test_invalid_spec_raises_value_error(self):
        from backtest import run_backtest
        from wizard.optimize import optimize

        close, volume = _market()
        with pytest.raises(ValueError, match="非法"):
            optimize({**_OPT_SPEC, "top_n": 99}, close=close, volume=volume,
                     run_backtest_fn=run_backtest)


# ---------- composite 组合策略 ----------

class _FixedStrategy:
    """返回固定权重面板的假成员策略（结构对齐 strategy.base.Strategy）。"""

    params_schema = []

    def __init__(self, sid: str, weights: pd.DataFrame):
        self.id = sid
        self.name = sid
        self.description = ""
        self._w = weights

    def resolve_params(self, overrides):
        return {}

    def target_weights(self, close, volume, params):
        return self._w.reindex(index=close.index, columns=close.columns).fillna(0.0)


@pytest.fixture()
def fake_members(monkeypatch):
    """注册两个假成员策略到内置注册表（测试后自动还原）。"""
    import strategy as strategy_pkg

    dates = pd.bdate_range("2024-01-02", periods=10)
    cols = ["600519.SH", "688981.SH"]
    wa = pd.DataFrame({"600519.SH": 1.0, "688981.SH": 0.0}, index=dates)
    wb = pd.DataFrame({"600519.SH": 0.0, "688981.SH": 1.0}, index=dates)
    monkeypatch.setitem(strategy_pkg.STRATEGIES, "fake_a", _FixedStrategy("fake_a", wa))
    monkeypatch.setitem(strategy_pkg.STRATEGIES, "fake_b", _FixedStrategy("fake_b", wb))
    close = pd.DataFrame(10.0, index=dates, columns=cols)
    volume = pd.DataFrame(1e6, index=dates, columns=cols)
    return close, volume


class TestComposite:
    def test_weighted_average_and_normalization(self, fake_members):
        """3:1 权重归一化为 0.75/0.25，组合权重 = Σ w×member_w，行和保持 1。"""
        from strategy.composite import CompositeStrategy

        close, volume = fake_members
        combo = CompositeStrategy({"id": "composite_t1", "name": "t", "members": [
            {"strategy_id": "fake_a", "weight": 3.0},
            {"strategy_id": "fake_b", "weight": 1.0},
        ]})
        out = combo.target_weights(close, volume, {})
        assert out["600519.SH"].iloc[-1] == pytest.approx(0.75)
        assert out["688981.SH"].iloc[-1] == pytest.approx(0.25)
        assert out.sum(axis=1).iloc[-1] == pytest.approx(1.0)
        # 落盘 spec 中成员权重已归一化
        assert combo.spec["members"][0]["weight"] == pytest.approx(0.75)

    def test_validation_errors(self):
        from strategy.composite import CompositeStrategy

        with pytest.raises(ValueError, match="members"):
            CompositeStrategy({"id": "composite_x", "name": "x", "members": []})
        with pytest.raises(ValueError, match="weight"):
            CompositeStrategy({"id": "composite_x", "name": "x",
                               "members": [{"strategy_id": "a", "weight": 0}]})

    def test_save_and_reload_via_custom_store(self, fake_members, tmp_path, monkeypatch):
        """composite spec 走 save_custom 存取；清缓存重载后 get_strategy 按 id 取回。"""
        import strategy as strategy_pkg
        from strategy import custom_store
        from strategy.composite import CompositeStrategy

        monkeypatch.setattr(custom_store, "_STORE", tmp_path / "custom.json")
        monkeypatch.setattr(custom_store, "_cache", {})
        monkeypatch.setattr(custom_store, "_loaded", False)
        spec = {"id": "composite_t2", "name": "组合", "type": "composite", "members": [
            {"strategy_id": "fake_a", "weight": 0.6},
            {"strategy_id": "fake_b", "weight": 0.4},
        ]}
        saved = custom_store.save_custom(spec)
        assert saved.id == "composite_t2"
        # 模拟重启：清内存缓存，从磁盘重新加载
        monkeypatch.setattr(custom_store, "_cache", {})
        monkeypatch.setattr(custom_store, "_loaded", False)
        loaded = strategy_pkg.get_strategy("composite_t2")
        assert isinstance(loaded, CompositeStrategy)
        assert [m[0] for m in loaded.members] == ["fake_a", "fake_b"]

    def test_dsl_spec_still_saves(self, tmp_path, monkeypatch):
        """回归：DSL spec 的保存路径不受 composite 分发影响。"""
        from strategy import custom_store
        from strategy.dsl import DslStrategy

        monkeypatch.setattr(custom_store, "_STORE", tmp_path / "custom.json")
        monkeypatch.setattr(custom_store, "_cache", {})
        monkeypatch.setattr(custom_store, "_loaded", False)
        spec = {"id": "t_dsl_save", "name": "dsl",
                "factors": [{"name": "momentum", "window": 20, "weight": 0.6}],
                "top_n": 3, "rebalance_days": 5}
        saved = custom_store.save_custom(spec)
        assert isinstance(saved, DslStrategy)
        with pytest.raises(ValueError):
            custom_store.save_custom({**spec, "id": "t_bad", "top_n": 99})


# ---------- report narrative 回退 ----------

class _FakeExecutor:
    def account(self):
        return {"total_asset": 1_010_000.0, "cash": 500_000.0}

    def deals(self):
        return [{"symbol": "600519.SH", "side": "buy", "qty": 100,
                 "price": 1700.0, "deal_time": "10:00:00"}]

    def positions(self):
        return [{"symbol": "600519.SH", "qty": 100, "avg_cost": 1680.0}]


class _FakeQuoteEngine:
    def get_price(self, symbol):
        return 1720.0


def _name_of(symbol: str) -> str:
    return "贵州茅台"


class TestReportNarrative:
    def test_no_llm_config_narrative_empty(self, monkeypatch):
        """无 llm 配置：narrative 为空串，模板数据不受影响。"""
        monkeypatch.delenv("CUBE_LLM_API_KEY", raising=False)
        from report import daily_report

        rep = daily_report(_FakeExecutor(), _FakeQuoteEngine(), _name_of, llm_yaml_cfg=None)
        assert rep["narrative"] == ""
        assert rep["account"]["total_asset"] == 1_010_000.0
        assert rep["positions"] and rep["text"]

    def test_llm_failure_falls_back(self, monkeypatch):
        """LLM 调用抛异常：静默回退为空串，不影响其它字段。"""
        import wizard.llm as wizard_llm
        from report import daily_report

        def _boom(cfg, messages, **kwargs):
            raise RuntimeError("llm down")

        monkeypatch.setattr(wizard_llm, "chat_completion", _boom)
        rep = daily_report(_FakeExecutor(), _FakeQuoteEngine(), _name_of,
                           llm_yaml_cfg={"api_key": "k", "base_url": "http://x", "model": "m"})
        assert rep["narrative"] == ""
        assert rep["float_pnl"] == pytest.approx(4000.0)

    def test_llm_success_fills_narrative(self, monkeypatch):
        import wizard.llm as wizard_llm
        from report import daily_report

        monkeypatch.setattr(wizard_llm, "chat_completion",
                            lambda cfg, messages, **kwargs: "今日账户小幅上涨，持仓浮盈。")
        rep = daily_report(_FakeExecutor(), _FakeQuoteEngine(), _name_of,
                           llm_yaml_cfg={"api_key": "k"})
        assert rep["narrative"] == "今日账户小幅上涨，持仓浮盈。"


# ---------- 参数依赖标注（depends_on） ----------

class TestParamDependencySchema:
    def test_depends_on_refs_valid(self):
        """depends_on 必须指向同 schema 中存在的 0/1 int 开关参数，且不能自指。"""
        from strategy import STRATEGIES
        for s in STRATEGIES.values():
            by_key = {p.key: p for p in s.params_schema}
            for p in s.params_schema:
                if p.depends_on is None:
                    continue
                assert p.depends_on != p.key
                assert p.depends_on in by_key, f"{s.id}.{p.key} 依赖了不存在的参数 {p.depends_on}"
                sw = by_key[p.depends_on]
                assert sw.type == "int" and sw.min == 0 and sw.max == 1, \
                    f"{s.id}.{p.key} 的依赖 {p.depends_on} 不是 0/1 开关"

    def test_ai_momentum_top_regime_params(self):
        """AI 动量优选（Regime 动态版）：动态仓位/调仓参数齐备，旧风控覆盖层参数已移除。"""
        from strategy import STRATEGIES
        s = STRATEGIES["ai_momentum_top"]
        keys = {p.key for p in s.params_schema}
        assert {"top_n", "trend_th", "range_th",
                "rebalance_trending", "rebalance_transition", "rebalance_ranging"} <= keys
        assert "use_risk_overlay" not in keys and "rebalance_days" not in keys
