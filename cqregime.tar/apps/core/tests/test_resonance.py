"""resonance_macd 策略测试：金叉状态机、零轴带、ATR/死叉出场、赛道约束、当日行无前瞻。"""
import json
import numpy as np
import pandas as pd
import pytest

from strategy.resonance_macd import ResonanceMacdStrategy

DATES = pd.bdate_range("2024-01-02", periods=90)
N = len(DATES)


def _series(flat_days: int, flat_px: float, tail_returns, pre_returns=None) -> pd.Series:
    """flat_days 天平盘 + 前置/尾部收益序列拼成的价格线。"""
    rets = np.zeros(N)
    if pre_returns is not None:
        rets[: len(pre_returns)] = pre_returns
    rets[flat_days:] = list(tail_returns)[: N - flat_days]
    px = flat_px * np.cumprod(1.0 + rets)
    return pd.Series(px, index=DATES)


def _mk_strategy(pool_map, tmp_path, **params):
    """pool_map: {symbol: sector}；写入临时池文件后构造策略。"""
    pool = {"stocks": [{"stock_code": s, "name": s, "sector": sec} for s, sec in pool_map.items()]}
    p = tmp_path / "pool.json"
    p.write_text(json.dumps(pool, ensure_ascii=False), encoding="utf-8")
    st = ResonanceMacdStrategy(pool_path=str(p))
    st.set_bars_provider(lambda sym: bars[sym])
    st._default_params = params
    return st


def _run(st: ResonanceMacdStrategy, close: pd.DataFrame, **params) -> pd.DataFrame:
    return st.target_weights(close, close.copy(), {"max_pos": 3, "gc_state_days": 2,
                                                   "atr_mult": 1.5, **params})


bars: dict = {}


def _install_bars(close: pd.DataFrame) -> None:
    global bars
    bars = {s: pd.DataFrame({"open": close[s], "high": close[s] * 1.004,
                             "low": close[s] * 0.996, "close": close[s],
                             "volume": 1000.0}, index=close.index) for s in close.columns}


class TestEntry:
    def test_golden_cross_near_zero_enters(self, tmp_path):
        # 60 天平盘后温和上涨：DIF 贴近零轴上穿 DEA → 金叉当日/次日可入场
        close = pd.DataFrame({"A.SH": _series(60, 100.0, np.full(30, 0.004))})
        _install_bars(close)
        st = _mk_strategy({"A.SH": "半导体设备"}, tmp_path)
        w = _run(st, close)
        held_days = w["A.SH"] > 0
        assert held_days.any(), "金叉后应持仓"
        first = held_days.idxmax()
        # 入场不早于金叉（60 天平盘后），且不晚于金叉后 1 天
        assert first >= DATES[60]
        # 单票权重恒为 1/max_pos
        assert w.loc[held_days, "A.SH"].max() == pytest.approx(1 / 3)

    def test_cross_far_from_zero_rejected(self, tmp_path):
        # 深跌后急反弹：DIF 上穿时远离零轴下方（dif_pct < -0.5%）→ 不允许入场
        pre = np.zeros(60)
        pre[20:50] = -0.012          # 30 天阴跌
        close = pd.DataFrame({"A.SH": _series(50, 100.0, np.full(40, 0.02), pre_returns=pre)})
        _install_bars(close)
        st = _mk_strategy({"A.SH": "半导体设备"}, tmp_path)
        w = _run(st, close)
        assert not (w["A.SH"] > 0).any(), "远离零轴的金叉不得入场"

    def test_age_over_window_no_new_entry(self, tmp_path):
        # 金叉后第 3 天起（age>=2）不再新开仓：构造两只票错峰金叉，B 的金叉发生在 A 之后
        # 若状态窗口失效，B 会在 age>=2 的日子里被反复买入，持仓起点会异常提前/重复
        a = _series(50, 100.0, np.full(40, 0.004))
        b = _series(70, 100.0, np.full(20, 0.004))
        close = pd.DataFrame({"A.SH": a, "B.SH": b})
        _install_bars(close)
        st = _mk_strategy({"A.SH": "半导体设备", "B.SH": "封测OSAT"}, tmp_path)
        w = _run(st, close, max_pos=1)  # max_pos=1：A 占槽后 B 必须等 A 出场
        assert (w["A.SH"] > 0).any()
        # A 一直持有（温和上涨无止损/死叉），B 永远无法进场
        assert not (w["B.SH"] > 0).any()


class TestExit:
    def test_trailing_stop_exit(self, tmp_path):
        # 先温和上涨入场，随后断崖下跌：即使 MACD 尚未死叉，ATR 追踪止损必须出场
        tail = np.concatenate([np.full(20, 0.004), np.full(10, -0.03)])
        close = pd.DataFrame({"A.SH": _series(60, 100.0, tail)})
        _install_bars(close)
        st = _mk_strategy({"A.SH": "半导体设备"}, tmp_path)
        w = _run(st, close)
        held = w["A.SH"] > 0
        assert held.any(), "应先入场"
        assert not held.iloc[-1], "急跌后必须出场（止损或死叉）"
        # 出场日之后不得重新持有（同一上涨段不会再次金叉）
        assert not held[held.idxmax():][-5:].any()


class TestPortfolioRules:
    def test_sector_cap_one(self, tmp_path):
        # 两只票同赛道同日金叉：只能进一只（|DIF/close| 更小者优先）
        a = _series(60, 100.0, np.full(30, 0.004))
        b = _series(60, 50.0, np.full(30, 0.006))  # 涨更急 → DIF 偏离更大 → 排名靠后
        close = pd.DataFrame({"A.SH": a, "B.SH": b})
        _install_bars(close)
        st = _mk_strategy({"A.SH": "半导体设备", "B.SH": "半导体设备"}, tmp_path)
        w = _run(st, close)
        both = (w["A.SH"] > 0) & (w["B.SH"] > 0)
        assert not both.any(), "同赛道不得同时持有两只"
        assert (w["A.SH"] > 0).any(), "应优先持有更贴零轴的 A"

    def test_max_pos_limit(self, tmp_path):
        series = {f"S{i}.SH": _series(55 + i * 5, 100.0, np.full(N - 55 - i * 5, 0.004))
                  for i in range(4)}
        close = pd.DataFrame(series)
        _install_bars(close)
        st = _mk_strategy({s: f"赛道{i}" for i, s in enumerate(series)}, tmp_path)
        w = _run(st, close, max_pos=2)
        n_held = (w > 0).sum(axis=1)
        assert n_held.max() <= 2


class TestNoLookahead:
    def test_live_row_does_not_change_signals(self, tmp_path):
        hist = pd.DataFrame({"A.SH": _series(60, 100.0, np.full(30, 0.004))})
        _install_bars(hist)
        st = _mk_strategy({"A.SH": "半导体设备"}, tmp_path)
        w_hist = _run(st, hist)

        today = pd.Timestamp.now().normalize()
        live = hist.copy()
        live.loc[today] = hist.iloc[-1] * 0.8   # 当日实时暴跌 20%（盘中噪声）
        _install_bars(hist)  # provider 只有已收盘历史
        w_live = _run(st, live)
        assert w_live.loc[today].equals(w_hist.iloc[-1]), "当日行应沿用前一交易日决策"
        # 历史部分的决策不受当日行影响
        pd.testing.assert_frame_equal(w_live.iloc[:-1], w_hist, check_freq=False)


class TestDefaultPool:
    def test_default_pool_loads_from_repo(self):
        # 仓库内 configs/resonance_pool.json 必须能被默认路径加载（142 只带 sector）
        st = ResonanceMacdStrategy()
        assert len(st._pool) == 142
        assert st._sector_of.get("688020.SH")  # 方邦股份在池且有赛道

    def test_missing_pool_falls_back_to_watchlist(self, tmp_path):
        st = ResonanceMacdStrategy(pool_path=str(tmp_path / "none.json"))
        close = pd.DataFrame({"X.SH": _series(0, 10.0, np.zeros(N))})
        assert st._universe(close) == ["X.SH"]


class TestRankToggle:
    def test_cand_key_modes(self):
        """排名开关：dif 模式 key=|DIF/close|（小优先）；动量模式 key=-(动量+0.5×量比)（大优先）。"""
        idx = pd.bdate_range("2024-01-02", periods=5)
        feat = {"A.SH": {"dif_pct": pd.Series([0.001] * 5, index=idx)},
                "B.SH": {"dif_pct": pd.Series([0.004] * 5, index=idx)}}
        mom = pd.DataFrame({"A.SH": [0.0] * 5, "B.SH": [2.0] * 5}, index=idx)
        vol = pd.DataFrame({"A.SH": [0.0] * 5, "B.SH": [0.0] * 5}, index=idx)
        t = idx[-1]
        k_a_dif = ResonanceMacdStrategy._cand_key("A.SH", t, feat, None, None, False)
        k_b_dif = ResonanceMacdStrategy._cand_key("B.SH", t, feat, None, None, False)
        assert k_a_dif < k_b_dif, "dif 模式：贴零轴的 A 优先"
        k_a_mom = ResonanceMacdStrategy._cand_key("A.SH", t, feat, mom, vol, True)
        k_b_mom = ResonanceMacdStrategy._cand_key("B.SH", t, feat, mom, vol, True)
        assert k_b_mom < k_a_mom, "动量模式：动量高的 B 优先"
        # 动量数据缺失的票直接跳过
        nan_mom = pd.DataFrame({"A.SH": [np.nan] * 5}, index=idx)
        assert ResonanceMacdStrategy._cand_key("A.SH", t, feat, nan_mom, vol, True) is None

    def test_full_sim_rank_momentum(self, tmp_path):
        # 全链路冒烟：rank_momentum=1 也能正常跑完组合模拟
        close = pd.DataFrame({"A.SH": _series(60, 100.0, np.full(30, 0.004)),
                              "B.SH": _series(60, 50.0, np.full(30, 0.008))})
        _install_bars(close)
        st = _mk_strategy({"A.SH": "半导体设备", "B.SH": "封测OSAT"}, tmp_path)
        w = _run(st, close, max_pos=1, rank_momentum=1)
        assert (w.sum(axis=1) > 0).any()


class TestScreenRows:
    def test_rows_match_selection_and_signals(self, tmp_path):
        close = pd.DataFrame({"A.SH": _series(60, 100.0, np.full(30, 0.004)),
                              "B.SH": _series(70, 50.0, np.full(20, 0.004)),
                              "C.SH": _series(88, 30.0, np.full(2, 0.004))})
        _install_bars(close)
        st = _mk_strategy({"A.SH": "半导体设备", "B.SH": "封测OSAT", "C.SH": "硅片"}, tmp_path)
        rows = st.screen_rows(close, close.copy(), {"max_pos": 3, "gc_state_days": 2,
                                                    "atr_mult": 1.5})
        by_sym = {r["symbol"]: r for r in rows}
        # A：金叉日入选后一路持有至今（age 已 29）——入场窗口只关新买，不关持有
        assert by_sym["A.SH"]["selected"], "A 应在持仓名单"
        assert by_sym["A.SH"]["gc_age"] == 29
        assert not by_sym["A.SH"]["entry"], "age≥2 不再是新入场信号"
        assert by_sym["A.SH"]["macd_state"] == "金叉第29天"
        # C：最后一天刚金叉（age=1），正处于入场窗口
        assert by_sym["C.SH"]["entry"] and by_sym["C.SH"]["gc_age"] == 1
        assert by_sym["C.SH"]["near_zero"]
        # 选中的排最前
        assert rows[0]["selected"]
        # 所有行都带 sector 与 ATR 参考
        assert all("sector" in r and "atr_pct" in r for r in rows)
        # 必须能被 JSON 序列化（防 numpy 类型泄漏导致 FastAPI 500）
        json.dumps(rows)

    def test_default_base_screen_rows_via_weights(self, tmp_path):
        # 基类默认实现：按目标权重最后一行给选中名单
        from strategy.ai_momentum_top import AiMomentumTopStrategy
        st = AiMomentumTopStrategy()
        close = pd.DataFrame({f"S{i}.SH": _series(0, 10.0 + i, np.full(N, 0.001 * (i + 1)))
                              for i in range(6)})
        rows = st.screen_rows(close, close.copy(), {"top_n": 3})
        sel = [r for r in rows if r["selected"]]
        assert len(sel) == 3, "默认实现选中数应等于 top_n"
