"""ai_momentum_top Regime 动态版测试：

- 四因子打分方向语义（动量 / 波动惩罚 / 稳定性 ER）
- Wilder ADX 趋势强度
- Regime 分数（沪深300 指数驱动 / 指数缺失时池内代理退化）
- 仓位比例分段公式、调仓间隔三档映射
- 动态间隔换股节奏、仓位比例逐日缩放、T+1 当日行语义
"""
import numpy as np
import pandas as pd
import pytest

from strategy.ai_momentum_top import AiMomentumTopStrategy

N = 260
DATES = pd.bdate_range("2024-01-02", periods=N)


def _mk_pool(n=N):
    """三只辨识度高的票：A 稳涨、B 平盘、C 阴跌。"""
    a = 100 * np.cumprod(1 + np.full(n, 0.004))
    b = np.full(n, 100.0)
    c = 100 * np.cumprod(1 - np.full(n, 0.004))
    return pd.DataFrame({"A.SH": a, "B.SH": b, "C.SH": c}, index=DATES[:n])


def _index_df(rets, amp=0.004):
    """按日收益序列造指数 OHLC（high/low 按振幅包络）。"""
    rets = np.asarray(rets, dtype=float)
    close = 4000 * np.cumprod(1 + rets)
    df = pd.DataFrame({
        "open": close * (1 - amp / 2),
        "high": close * (1 + amp),
        "low": close * (1 - amp),
        "close": close,
    }, index=DATES[: len(rets)])
    return df


def _strategy_with_index(index_df):
    st = AiMomentumTopStrategy()
    st.set_bars_provider(lambda sym: index_df)
    return st


_DEFAULTS = AiMomentumTopStrategy().resolve_params({})


def _p(**kw):
    return {**_DEFAULTS, **kw}


# ---------- 四因子打分 ----------

class TestCompositeScore:
    def test_momentum_ordering(self):
        close = _mk_pool()
        st = AiMomentumTopStrategy()
        score = st.composite_score(close, _p(w_mom=1.0, w_vol=0.0, w_bias=0.0, w_stability=0.0))
        last = score.iloc[-1]
        assert last["A.SH"] > last["B.SH"] > last["C.SH"]

    def test_vol_weight_punishes_choppy(self):
        rng = np.random.default_rng(3)
        calm = 100 * np.cumprod(1 + rng.normal(0, 0.003, N))
        wild = 100 * np.cumprod(1 + rng.normal(0, 0.05, N))
        close = pd.DataFrame({"CALM.SH": calm, "WILD.SH": wild}, index=DATES)
        st = AiMomentumTopStrategy()
        score = st.composite_score(close, _p(w_mom=0.0, w_vol=-1.0, w_bias=0.0, w_stability=0.0))
        assert score["CALM.SH"].iloc[-1] > score["WILD.SH"].iloc[-1]

    def test_stability_prefers_smooth_trend(self):
        # 两条净值终点相近的线：平滑慢涨 vs 大幅上下波动，ER 高者得分高
        n = N
        smooth = 100 * np.cumprod(1 + np.full(n, 0.002))
        swing = np.ones(n)
        swing[::2] = 0.03
        swing[1::2] = -0.027  # 锯齿，但长期净方向微正
        choppy = 100 * np.cumprod(1 + swing)
        close = pd.DataFrame({"SM.SH": smooth, "CH.SH": choppy}, index=DATES)
        st = AiMomentumTopStrategy()
        score = st.composite_score(close, _p(w_mom=0.0, w_vol=0.0, w_bias=0.0, w_stability=1.0))
        assert score["SM.SH"].iloc[-1] > score["CH.SH"].iloc[-1]

    def test_warmup_period_is_nan(self):
        close = _mk_pool(n=30)
        st = AiMomentumTopStrategy()
        score = st.composite_score(close, _p())
        assert score.iloc[:20].isna().all().all(), "lookback 预热期不得参与选股"


# ---------- ADX ----------

class TestAdx:
    def test_strong_trend_beats_flat(self):
        trend = _index_df(np.full(N, 0.002), amp=0.003)
        # 微幅拉锯：DM 有定义但方向互相抵消，ADX 应远低于单边趋势
        chop = np.where(np.arange(N) % 2 == 0, 0.0005, -0.0005)
        flat = _index_df(chop, amp=0.003)
        adx_trend = AiMomentumTopStrategy._adx(trend["high"], trend["low"], trend["close"], 14)
        adx_flat = AiMomentumTopStrategy._adx(flat["high"], flat["low"], flat["close"], 14)
        assert adx_trend.iloc[-1] > 25, "单边趋势 ADX 应显著"
        assert adx_trend.iloc[-1] > adx_flat.iloc[-1]


# ---------- Regime 分数 ----------

class TestRegimeScore:
    def test_bull_index_high_score(self):
        # 慢牛：稳涨 + 窄振幅 → 均线多头 + 低波分位 → 高分
        idx = _index_df(np.full(N, 0.0015), amp=0.002)
        st = _strategy_with_index(idx)
        regime = st.regime_score(_mk_pool(), _p())
        assert regime.iloc[-1] >= 0.55, f"慢牛应为趋势市，实际 {regime.iloc[-1]:.3f}"

    def test_crash_index_low_score(self):
        # 前 200 日慢牛建立高位均线，末 60 日带反抽的剧烈下跌：
        # 均线空头排列 + 波动率飙至满分位 → 两项归零。注意 ADX 方向无关（文档口径），
        # 单边暴跌也是"强趋势"，分数被顶到 0.45 边界——因此断言不到趋势市，而非深跌。
        crash_leg = np.where(np.arange(60) % 3 == 2, 0.008, -0.02)  # 跌两天弹一天
        rets = np.concatenate([np.full(200, 0.0015), crash_leg])
        idx = _index_df(rets, amp=0.02)
        st = _strategy_with_index(idx)
        regime = st.regime_score(_mk_pool(), _p())
        assert regime.iloc[-1] <= 0.45 + 1e-9, f"暴跌市不应进入趋势市，实际 {regime.iloc[-1]:.3f}"

    def test_sideways_chop_low_score(self):
        # 高位宽幅拉锯（无方向高波动）：ADX 低 + 排列失效 + 高波分位 → 明确震荡市
        chop = np.where(np.arange(60) % 2 == 0, 0.012, -0.012)
        rets = np.concatenate([np.full(200, 0.0015), chop])
        idx = _index_df(rets, amp=0.02)
        st = _strategy_with_index(idx)
        regime = st.regime_score(_mk_pool(), _p())
        assert regime.iloc[-1] < 0.45, f"拉锯市应为震荡市，实际 {regime.iloc[-1]:.3f}"

    def test_fallback_without_provider(self):
        # 无指数源：池内等权代理（ADX 计 0），不崩、分数在 0~1
        st = AiMomentumTopStrategy()
        regime = st.regime_score(_mk_pool(), _p())
        assert ((regime >= 0) & (regime <= 1)).all()


# ---------- 仓位比例 / 调仓间隔映射 ----------

class TestMappings:
    def test_position_ratio_segments(self):
        s = pd.Series([0.6, 0.5, 0.475, 0.225, 0.0])
        pos = AiMomentumTopStrategy.position_ratio(s, _p())
        assert pos.iloc[0] == 1.0                       # 趋势市满仓
        assert pos.iloc[1] == pytest.approx(0.75)       # 过渡区中点
        assert pos.iloc[2] == pytest.approx(0.625)      # 过渡区线性
        assert pos.iloc[3] == pytest.approx(0.25)       # 震荡区 0.225/0.45×0.5
        assert pos.iloc[4] == 0.0                       # 极弱空仓

    def test_rebalance_interval_tiers(self):
        s = pd.Series([0.6, 0.5, 0.3])
        iv = AiMomentumTopStrategy.rebalance_interval(s, _p())
        assert list(iv) == [10, 5, 3]


# ---------- 权重：动态间隔 + 仓位缩放 ----------

class TestBaseWeights:
    def test_weights_scaled_by_position_ratio(self):
        idx = _index_df(np.full(N, 0.0015), amp=0.002)  # 慢牛 → 满仓
        st = _strategy_with_index(idx)
        close = _mk_pool()
        p = _p(top_n=2)
        w = st._base_weights(close, p)
        pos = st.position_ratio(st.regime_score(close, p), p)
        held = w.sum(axis=1) > 0
        assert held.any()
        for dt in close.index[held]:
            assert w.loc[dt].sum() == pytest.approx(pos.loc[dt], abs=1e-9)

    @staticmethod
    def _rotating_pool():
        """4 票轮动领涨：60 日前全部平盘，之后每 6 天换一只 +3%/天冲刺 6 天。
        轮动快于趋势市调仓间隔（10 日），慢频调仓必然错过部分轮动——
        震荡市（3 日间隔）换股次数因此严格更多。"""
        n = N
        px = {}
        for i in range(4):
            rets = np.zeros(n)
            for start in range(60 + i * 6, n, 24):
                rets[start:start + 6] = 0.03
            px[f"S{i}.SH"] = 100 * np.cumprod(1 + rets)
        return pd.DataFrame(px, index=DATES)

    def test_trending_market_rebalance_every_10_days(self):
        idx = _index_df(np.full(N, 0.0015), amp=0.002)  # 慢牛 → 趋势市，间隔 10
        st = _strategy_with_index(idx)
        close = self._rotating_pool()
        w = st._base_weights(close, _p(top_n=1))
        sel = w.gt(0).astype(int)
        changes = (sel.diff().abs().sum(axis=1) > 0)
        change_days = list(close.index[changes])
        assert change_days, "领涨轮动应引起换股"
        # 波动率分位需 60+50 日预热，预热期 Regime 填中性 0.5（间隔 5）；
        # 预热结束后进入趋势市，换股间隔必须 ≥10
        late = [d for d in change_days if close.index.get_loc(d) >= 115]
        assert len(late) >= 3, "预热后应有多次换股"
        gaps = np.diff([close.index.get_loc(d) for d in late])
        assert all(g >= 10 for g in gaps), f"趋势市换股间隔应≥10，实际 {gaps}"

    def test_ranging_market_rebalances_more_often(self):
        # 宽幅拉锯 → 震荡市（间隔 3）；慢牛 → 趋势市（间隔 10），前者换股应更频繁
        chop = np.where(np.arange(N) % 2 == 0, 0.012, -0.012)
        idx_range = _index_df(chop, amp=0.02)
        idx_trend = _index_df(np.full(N, 0.0015), amp=0.002)
        close = self._rotating_pool()

        def n_rebalances(idx_df):
            st = _strategy_with_index(idx_df)
            w = st._base_weights(close, _p(top_n=1))
            sel = w.gt(0).astype(int)
            return int((sel.diff().abs().sum(axis=1) > 0).sum())

        assert n_rebalances(idx_range) > n_rebalances(idx_trend)

    def test_live_row_passthrough(self):
        # 当日实时行不参与决策：末行 = 前一交易日目标（T+1 语义）
        idx = _index_df(np.full(N, 0.0015), amp=0.002)
        st = _strategy_with_index(idx)
        close = _mk_pool()
        today = pd.Timestamp.now().normalize()
        live = close.copy()
        live.loc[today] = [999.0, 1.0, 500.0]  # 夸张的盘中价不得改变决策
        w = st.target_weights(live, live.copy(), _p(top_n=2))
        assert w.index[-1] == today
        assert w.iloc[-1].equals(w.iloc[-2])


# ---------- schema ----------

class TestSchema:
    def test_regime_params_present_no_risk_overlay(self):
        st = AiMomentumTopStrategy()
        keys = {p.key for p in st.params_schema}
        assert {"top_n", "lookback", "w_mom", "w_vol", "w_bias", "w_stability",
                "adx_period", "ma_short", "ma_long", "vol_window", "vol_lookback",
                "trend_th", "range_th",
                "rebalance_trending", "rebalance_transition", "rebalance_ranging"} <= keys
        assert "use_risk_overlay" not in keys and "rebalance_days" not in keys
        assert all(p.depends_on is None for p in st.params_schema)
        defaults = st.resolve_params({})
        assert defaults["top_n"] == 8
