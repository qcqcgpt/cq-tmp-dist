"""cube-core：立方量化交易核心服务（端口 8700，前缀 /api）。

模块组装：MockDataSource -> DataHub -> QuoteEngine / 策略 / 回测 / 模拟盘，
全部通过构造函数依赖注入，替换数据源时无需改动上层代码。
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import sys
from contextlib import asynccontextmanager
from pathlib import Path
from typing import List, Optional

# 让仓库内共享包与本地子包可导入（uvicorn 在任意 cwd 下启动均可）
_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(_ROOT / "packages"))
sys.path.insert(0, str(_ROOT / "apps" / "core"))

from fastapi import Body, FastAPI, HTTPException, Query, Request, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from protocol import (
    BacktestRequest,
    BacktestResult,
    FactorInfo,
    OkResponse,
    OrderRequest,
    PaperAccount,
    PaperStartRequest,
    Quote,
    StrategyInfo,
    SymbolInfo,
    load_config,
)

from backtest import run_backtest
from datahub import DataHub, MockDataSource
from datahub.quote_engine import QuoteEngine
from factorlab import list_factors
from paper import EventBus, PaperEngine
from strategy import get_strategy, list_strategy_infos
from live import ExecutorClient, ExecutorHttpError, normalize_symbol
from autotrade import AutoTradeEngine, load_auto_state
from alerts import AlertManager
from regime import DataNotReady, RegimeMonitor
from datahub.hub import append_live_row, append_live_volume_row
from screener import factor_screen
from screener import screen as run_screen
from report import daily_report
from wizard import chat as wizard_chat
from wizard.legacy import parse_intent
from wizard.optimize import optimize as wizard_optimize
from wizard.optimize import optimize_builtin as wizard_optimize_builtin
from strategy.composite import CompositeStrategy
from strategy.custom_store import delete_custom, save_custom

VERSION = "0.1.0"

# ---------- 组装（依赖注入） ----------
_cfg = load_config()
_core_cfg = _cfg.get("core", {})
_paper_cfg = _cfg.get("paper", {})
# core -> executor/datafeed 的出站认证令牌（与远端 security.remote_token 一致）
_remote_token = str(_cfg.get("security", {}).get("remote_token", "") or "")

if _core_cfg.get("data_source") == "xt_remote":
    # 真实行情：HTTP 调用 Windows 上的 cube-datafeed（公网直连，X-Cube-Token 认证）
    from datahub.remote_quote_engine import RemoteQuoteEngine
    from datahub.xt_remote_source import XtRemoteSource

    _xt_remote_url = _core_cfg.get("xt_remote_url")
    if not _xt_remote_url:
        raise RuntimeError(
            "配置缺失：data_source=xt_remote 时必须在 yaml 的 core.xt_remote_url 配置 "
            "datafeed 地址（如 http://<云机EIP>:8702），不再提供默认端口")
    _remote_source = XtRemoteSource(
        base_url=_xt_remote_url,
        watchlist=_core_cfg.get("watchlist", []),
        history_start=_core_cfg.get("history_start", "2023-01-01"),
        timeout=float(_core_cfg.get("xt_remote_timeout", 30.0)),  # 首次批量下载慢，8s 不够
        token=_remote_token,
    )
    hub = DataHub(_remote_source)
    quote_engine = RemoteQuoteEngine(_remote_source)
    _remote_source.warmup()  # 后台预热日线缓存：首个回测/选股请求不必串行冷拉全池
else:
    hub = DataHub(MockDataSource(seed=_core_cfg.get("mock_seed", 20240101),
                                 start=_core_cfg.get("history_start", "2023-01-01")))
    quote_engine = QuoteEngine(hub, seed=_core_cfg.get("mock_seed", 20240101))
event_bus = EventBus()
paper_engine = PaperEngine(
    hub,
    quote_engine,
    event_bus,
    initial_cash=_paper_cfg.get("initial_cash", 1_000_000),
    invest_pct=_paper_cfg.get("invest_pct", 0.95),
    rebalance_interval_sec=_paper_cfg.get("rebalance_interval_sec", 10),
)

# 实盘执行端（公网直连）与自动交易/报警引擎
_live_cfg = _cfg.get("live", {})
_executor_url = _live_cfg.get("executor_url")
if not _executor_url:
    raise RuntimeError(
        "配置缺失：必须在 yaml 的 live.executor_url 配置实盘执行端地址"
        "（如 http://<云机EIP>:8701），不再提供默认端口")
executor_client = ExecutorClient(_executor_url, token=_remote_token)
autotrade = AutoTradeEngine(hub, quote_engine, executor_client, event_bus)
alert_mgr = AlertManager(event_bus)
# 市场状态温度计：每日收盘后自动监控（反转 vs 等权基准），切换时经 /ws/events 报警
regime_monitor = RegimeMonitor(hub, event_bus, run_backtest)


def _live_call(fn):
    """实盘代理统一异常处理：executor 业务错误透传状态码，网络不可达 -> 502。"""
    try:
        return fn()
    except ExecutorHttpError as exc:
        raise HTTPException(status_code=exc.status_code, detail=exc.detail)
    except RuntimeError as exc:
        raise HTTPException(status_code=502, detail=str(exc))


# ---------- WebSocket 连接管理 ----------
class QuotesWsManager:
    def __init__(self) -> None:
        self._clients: set[WebSocket] = set()

    async def add(self, ws: WebSocket) -> None:
        self._clients.add(ws)

    def remove(self, ws: WebSocket) -> None:
        self._clients.discard(ws)

    async def broadcast(self, payload: dict) -> None:
        dead = []
        for ws in list(self._clients):
            try:
                await ws.send_json(payload)
            except Exception:
                dead.append(ws)
        for ws in dead:
            self.remove(ws)


quotes_ws = QuotesWsManager()


async def quotes_broadcaster() -> None:
    """每 1 秒推进 mock 行情并向所有订阅者推送全宇宙快照。"""
    while True:
        await asyncio.sleep(1.0)
        try:
            # step() 对真实行情源是同步 HTTP（隧道抖动可达 8s），放线程池避免冻结事件循环
            await asyncio.get_running_loop().run_in_executor(None, quote_engine.step)
            alert_mgr.check(quote_engine)
            payload = {"type": "quotes", "data": [q.model_dump() for q in quote_engine.snapshot()]}
            await quotes_ws.broadcast(payload)
        except Exception as exc:
            # 单次行情/报警异常只记日志：循环必须存活，否则行情推送永久静默停摆
            # （CancelledError 继承 BaseException，不在此吞掉，关停流程不受影响）
            logging.getLogger("main").warning("行情广播循环异常（继续运行）：%s", exc)


async def regime_scheduler() -> None:
    """每分钟检查一次：收盘后且当日未算过则在后台线程跑温度计（pandas 重算不阻塞事件循环）。"""
    while True:
        await asyncio.sleep(60)
        try:
            if regime_monitor.due():
                await asyncio.get_running_loop().run_in_executor(None, regime_monitor.run_once)
        except DataNotReady as exc:
            logging.getLogger("main").info("温度计当日数据未就绪：%s", exc)
        except Exception as exc:
            # 与行情广播同原则：单次异常只记日志，调度循环必须存活
            logging.getLogger("main").warning("温度计计算异常（继续调度）：%s", exc)


@asynccontextmanager
async def lifespan(app: FastAPI):
    task = asyncio.create_task(quotes_broadcaster())
    regime_task = asyncio.create_task(regime_scheduler())
    yield
    task.cancel()
    regime_task.cancel()
    await autotrade.shutdown()
    await paper_engine.shutdown()


app = FastAPI(title="cube-core", version=VERSION, lifespan=lifespan)

# ---------- 安全：共享 token + CORS 白名单 ----------
# 真实资金端点零认证曾被任意网页/局域网直接调用（含 /api/live/sell_all）。
# token 取自 CUBE_TOKEN 环境变量或 yaml security.token，默认仅本机开发用。
import os as _os

_API_TOKEN = _os.environ.get("CUBE_TOKEN") or _cfg.get("security", {}).get("token") or "cubequant-dev-token"
_ALLOWED_ORIGINS = [
    "http://localhost:4173", "http://127.0.0.1:4173",   # 终端 preview
    "http://localhost:5173", "http://127.0.0.1:5173",   # 终端 dev
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=_ALLOWED_ORIGINS,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.middleware("http")
async def token_guard(request: Request, call_next):
    """/api/* 需携带 X-Cube-Token（/api/health 与 OPTIONS 预检放行）。"""
    path = request.url.path
    if path.startswith("/api/") and path != "/api/health" and request.method != "OPTIONS":
        if request.headers.get("X-Cube-Token") != _API_TOKEN:
            return JSONResponse(status_code=401, content={"detail": "未授权：缺少或错误的 X-Cube-Token"})
    return await call_next(request)


def _ws_token_ok(ws: WebSocket) -> bool:
    return ws.query_params.get("token") == _API_TOKEN


# ---------- HTTP 路由 ----------

# core 启动时检查：上次是否有未正常停止的自动交易（崩溃/强杀）。安全第一，只告警不自动恢复。
_AUTO_INTERRUPTED = bool(load_auto_state().get("running"))
if _AUTO_INTERRUPTED:
    logging.getLogger("main").warning(
        "检测到上次自动交易未正常停止（state/autotrade.json running=true），"
        "系统不会自动恢复交易；请人工确认持仓与在途委托后手动重启自动交易")


@app.get("/api/health")
def health() -> dict:
    return {"status": "ok", "version": VERSION, "auto_interrupted": _AUTO_INTERRUPTED}


@app.get("/api/symbols", response_model=List[SymbolInfo])
def symbols() -> List[SymbolInfo]:
    return hub.symbols()


@app.get("/api/quotes", response_model=List[Quote])
def quotes(symbols: Optional[str] = Query(default=None)) -> List[Quote]:
    # 立即推进一格，保证 HTTP 拉取也能看到价格游走
    quote_engine.step()
    wanted = [s.strip() for s in symbols.split(",") if s.strip()] if symbols else None
    return quote_engine.snapshot(wanted)


@app.get("/api/minute")
def api_minute(symbol: str = Query(...), period: str = Query(default="1m"),
               count: int = Query(default=240)) -> dict:
    """分钟级行情（透传 datafeed /md/minute，token 中间件自动生效）。"""
    if _core_cfg.get("data_source") != "xt_remote":
        raise HTTPException(status_code=400, detail="分钟行情需要真实数据源（data_source: xt_remote）")
    if period not in ("1m", "5m", "15m", "30m", "60m"):
        raise HTTPException(status_code=400, detail="period 仅支持 1m/5m/15m/30m/60m")
    try:
        import urllib.parse
        import urllib.request

        qs = urllib.parse.urlencode({"symbol": symbol, "period": period, "count": int(count)})
        req = urllib.request.Request(f"{_core_cfg['xt_remote_url']}/md/minute?{qs}")
        if _remote_token:
            req.add_header("X-Cube-Token", _remote_token)
        # datafeed 必须直连，绕过系统代理（Clash 等）
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        with opener.open(req, timeout=10.0) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"分钟行情获取失败（行情服务不可达？）：{exc}")


@app.get("/api/factors", response_model=List[FactorInfo])
def factors() -> List[FactorInfo]:
    return list_factors()


@app.get("/api/strategies", response_model=List[StrategyInfo])
def strategies() -> List[StrategyInfo]:
    return list_strategy_infos()


@app.post("/api/backtest", response_model=BacktestResult)
def backtest(req: BacktestRequest) -> BacktestResult:
    try:
        strategy = get_strategy(req.strategy_id)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    try:
        import pandas as pd

        if pd.Timestamp(req.start) > pd.Timestamp(req.end):
            raise ValueError
    except ValueError:
        raise HTTPException(status_code=400, detail="日期区间非法：start 必须不晚于 end，格式 YYYY-MM-DD")

    params = strategy.resolve_params(req.params)
    if hasattr(strategy, "set_bars_provider"):
        strategy.set_bars_provider(hub.daily_bars)  # resonance 需要 OHLC 计算 ATR
    close = hub.close_panel()
    weights = strategy.target_weights(close, hub.volume_panel(), params)
    return run_backtest(close, weights, req.start, req.end)


@app.post("/api/paper/start", response_model=OkResponse)
async def paper_start(req: PaperStartRequest) -> OkResponse:
    try:
        strategy = get_strategy(req.strategy_id)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    await paper_engine.start(strategy)
    return OkResponse(ok=True)


@app.post("/api/paper/stop", response_model=OkResponse)
async def paper_stop() -> OkResponse:
    await paper_engine.stop()
    return OkResponse(ok=True)


@app.get("/api/paper/account", response_model=PaperAccount)
def paper_account() -> PaperAccount:
    return paper_engine.account()


# ---------- 实盘代理（executor 经隧道） ----------

@app.get("/api/live/health")
def live_health() -> dict:
    return _live_call(executor_client.health)


@app.get("/api/live/account")
def live_account() -> dict:
    return _live_call(executor_client.account)


@app.get("/api/live/positions")
def live_positions() -> list:
    return _live_call(executor_client.positions)


@app.get("/api/live/orders")
def live_orders() -> list:
    return _live_call(executor_client.orders)


@app.get("/api/live/deals")
def live_deals() -> list:
    return _live_call(executor_client.deals)


@app.get("/api/live/risk")
def live_risk() -> dict:
    return _live_call(executor_client.risk_config)


@app.post("/api/live/risk")
def live_risk_set(cfg: dict = Body(...)) -> dict:
    return _live_call(lambda: executor_client.set_risk(cfg))


@app.post("/api/live/order")
def live_order(req: OrderRequest) -> dict:
    return _live_call(lambda: executor_client.order(
        normalize_symbol(req.symbol), req.side, req.qty, req.price_type, req.price))


@app.post("/api/live/cancel")
def live_cancel(order_id: str = Query(...)) -> dict:
    return _live_call(lambda: executor_client.cancel(order_id))


@app.post("/api/live/sell_all")
def live_sell_all(req: dict = Body(...)) -> dict:
    """一键清仓（真实资金账户，全部持仓市价卖出）。必须显式 {"confirm": true}。"""
    if (req or {}).get("confirm") is not True:
        raise HTTPException(status_code=400, detail="一键清仓需显式 {\"confirm\": true} 确认")
    return _live_call(executor_client.sell_all)


# ---------- 自动交易信号引擎 ----------

@app.get("/api/auto/status")
def auto_status() -> dict:
    return autotrade.status()


@app.get("/api/auto/logs")
def auto_logs() -> list:
    return autotrade.logs()


@app.post("/api/auto/start")
async def auto_start(req: dict = Body(...)) -> OkResponse:
    try:
        await autotrade.start(
            strategy_id=req.get("strategy_id", ""),
            params=req.get("params", {}),
            interval_sec=int(req.get("interval_sec", 60)),
            invest_pct=float(req.get("invest_pct", 0.95)),
            min_order_value=float(req.get("min_order_value", 3000.0)),
            confirm=bool(req.get("confirm", False)),
        )
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    except (ValueError, RuntimeError) as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return OkResponse(ok=True)


@app.post("/api/auto/stop")
async def auto_stop() -> OkResponse:
    await autotrade.stop()
    return OkResponse(ok=True)


@app.post("/api/auto/override/clear")
def auto_override_clear(req: dict = Body(...)) -> dict:
    """解除手动干预保护（不再买回 / 不自动卖出）：{"symbol": "688596.SH"} 单个，{} 全部。"""
    symbol = str((req or {}).get("symbol") or "").strip().upper()
    return {"ok": True, "cleared": autotrade.clear_override(symbol or None)}


@app.post("/api/auto/preview")
async def auto_preview(req: dict = Body(...)) -> dict:
    """切换预演（dry-run）：按给定配置返回预计买卖清单与估算金额，绝不下单。
    阻塞的行情/账户查询放线程池，避免冻结事件循环。"""
    try:
        return await asyncio.get_running_loop().run_in_executor(
            None,
            lambda: autotrade.preview(
                strategy_id=req.get("strategy_id", ""),
                params=req.get("params", {}) or {},
                invest_pct=float(req.get("invest_pct", 0.95)),
                min_order_value=float(req.get("min_order_value", 3000.0)),
            ),
        )
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except ExecutorHttpError as exc:
        raise HTTPException(status_code=exc.status_code, detail=exc.detail)
    except RuntimeError as exc:
        raise HTTPException(status_code=502, detail=str(exc))


# ---------- 选股器 ----------

def _enrich_screen_rows(rows: list) -> list:
    """选股结果补充名称/实时价/涨跌幅（以实时快照为准）。"""
    names = dict(hub.source.list_symbols())
    snap = {}
    for q in quote_engine.snapshot():  # Quote 模型 / dict 兼容
        d = q.model_dump() if hasattr(q, "model_dump") else q
        snap[d["symbol"]] = d
    for r in rows:
        r["name"] = names.get(r["symbol"], r["symbol"])
        q = snap.get(r["symbol"], {})
        r["price"] = q.get("price", 0.0)
        r["change_pct"] = q.get("change_pct", 0.0)
    return rows


@app.post("/api/screen/strategy")
def api_screen_strategy(req: dict = Body(...)) -> list:
    """跟随策略的选股：用指定策略自身的规则与排序输出候选名单（含信号明细）。"""
    sid = (req or {}).get("strategy_id", "")
    params = (req or {}).get("params") or {}
    try:
        strategy = get_strategy(sid)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    if hasattr(strategy, "set_bars_provider"):
        strategy.set_bars_provider(hub.daily_bars)  # resonance 需要 OHLC
    try:
        # 并入当日实时价：盘中排名随行情活起来；入选名单不受影响——
        # target_weights 内部会剥掉当日行，保持 T+1 口径与实盘一致
        close = append_live_row(hub.close_panel(), quote_engine.get_price)
        rows = strategy.screen_rows(close, hub.volume_panel(),
                                    strategy.resolve_params(params))
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"策略选股失败（行情服务不可达？）：{exc}")
    return _enrich_screen_rows(rows)


@app.post("/api/screen")
def api_screen(req: dict = Body(...)) -> list:
    if _core_cfg.get("data_source") != "xt_remote":
        raise HTTPException(status_code=400, detail="选股器需要真实数据源（data_source: xt_remote）")
    # 因子模式：factorlab 注册因子截面合成，面板并入当日实时价/量（盘中排名实时变化）
    factors = req.get("factors") or []
    if factors:
        try:
            close = append_live_row(hub.close_panel(), quote_engine.get_price)
            get_vol = getattr(quote_engine, "get_volume", None)
            volume = (append_live_volume_row(hub.volume_panel(), get_vol)
                      if get_vol else hub.volume_panel())
            rows = factor_screen(close, volume, factors, top=int(req.get("top", 20)))
        except KeyError as exc:
            raise HTTPException(status_code=400, detail=f"未注册的因子：{exc}")
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc))
        except Exception as exc:
            raise HTTPException(status_code=502, detail=f"因子选股失败（行情服务不可达？）：{exc}")
        return _enrich_screen_rows(rows)
    try:
        return run_screen(
            datafeed_url=_core_cfg.get("xt_remote_url", ""),
            sector=req.get("sector"),
            watchlist=_core_cfg.get("watchlist", []),
            momentum_days=int(req.get("momentum_days", 20)),
            min_momentum=req.get("min_momentum"),
            max_momentum=req.get("max_momentum"),
            min_volume_ratio=float(req.get("min_volume_ratio", 0.0)),
            pool_max=int(req.get("pool_max", 60)),
            top=int(req.get("top", 20)),
            token=_remote_token,
        )
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"选股失败（行情服务不可达？）：{exc}")


# ---------- 每日复盘 ----------

@app.get("/api/report/daily")
def api_report_daily() -> dict:
    return _live_call(lambda: daily_report(executor_client, quote_engine, hub.name_of,
                                           llm_yaml_cfg=_cfg.get("llm", {})))


# ---------- AI 向导 ----------

@app.post("/api/wizard/parse")
def api_wizard_parse(req: dict = Body(...)) -> dict:
    text = (req or {}).get("text", "")
    if not text.strip():
        raise HTTPException(status_code=400, detail="请描述你的策略意图")
    return parse_intent(text)


@app.post("/api/wizard/chat")
def api_wizard_chat(req: dict = Body(...)) -> dict:
    """AI 助手（LLM 主导）：策略生成/微调、市场点评、个股问答、知识科普、智能复盘。"""
    messages = (req or {}).get("messages") or []
    if not messages:
        raise HTTPException(status_code=400, detail="messages 不能为空")
    from strategy.custom_store import list_custom
    from wizard.assistant import assistant_chat

    def _create(msgs):
        # 面板拉取重（167 只），仅生成/微调意图才真正取数
        return wizard_chat(msgs, close=hub.close_panel(), volume=hub.volume_panel(),
                           run_backtest_fn=run_backtest, llm_yaml_cfg=_cfg.get("llm", {}))

    try:
        return assistant_chat(
            messages,
            hub=hub, quote_engine=quote_engine, live_client=executor_client,
            run_backtest_fn=run_backtest,
            report_fn=lambda: daily_report(executor_client, quote_engine, hub.name_of,
                                           llm_yaml_cfg=_cfg.get("llm", {})),
            get_strategy_fn=get_strategy,
            known_custom={s.name: s.id for s in list_custom()},
            create_fn=_create, llm_yaml_cfg=_cfg.get("llm", {}),
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@app.post("/api/wizard/optimize")
def api_wizard_optimize(req: dict = Body(...)) -> dict:
    """AI 策略教练：对 spec 做小网格寻优（训练段选优 + 样本外验证 + 过拟合评级）。"""
    spec = (req or {}).get("spec") or {}
    if not spec:
        raise HTTPException(status_code=400, detail="spec 不能为空")
    try:
        return wizard_optimize(
            spec,
            close=hub.close_panel(),
            volume=hub.volume_panel(),
            run_backtest_fn=run_backtest,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except RuntimeError as exc:
        raise HTTPException(status_code=500, detail=str(exc))
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"寻优失败：{exc}")


@app.post("/api/wizard/optimize_builtin")
def api_wizard_optimize_builtin(req: dict = Body(...)) -> dict:
    """内置策略参数寻优：以 schema 的 min/default/max 为轴做小网格回测
    （训练段选优 + 样本外验证 + 过拟合评级），返回最优参数与默认参数对照。"""
    sid = str((req or {}).get("strategy_id", "")).strip()
    if not sid:
        raise HTTPException(status_code=400, detail="strategy_id 不能为空")
    try:
        strategy = get_strategy(sid)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    if hasattr(strategy, "set_bars_provider"):
        strategy.set_bars_provider(hub.daily_bars)  # resonance 需要 OHLC 计算 ATR
    try:
        return wizard_optimize_builtin(
            strategy,
            close=hub.close_panel(),
            volume=hub.volume_panel(),
            run_backtest_fn=run_backtest,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except RuntimeError as exc:
        raise HTTPException(status_code=500, detail=str(exc))
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"寻优失败：{exc}")


# ---------- 自定义策略（DSL / 组合） ----------

@app.get("/api/strategies/custom")
def custom_strategies_list() -> list:
    from strategy.custom_store import list_custom
    return [s.spec for s in list_custom()]


@app.post("/api/strategies/custom")
def custom_strategies_save(spec: dict = Body(...)) -> dict:
    try:
        s = save_custom(spec)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except TypeError as exc:
        # 字段为 null/类型不符（如 weight: None 触发 float(None)）按 400 处理，不穿透成 500
        raise HTTPException(status_code=400, detail=f"策略规格字段类型非法：{exc}")
    return {"ok": True, "id": s.id, "name": s.name}


@app.post("/api/strategies/composite")
def strategies_composite_create(req: dict = Body(...)) -> dict:
    """创建组合策略：成员策略目标权重按 weight 加权平均（多策略并行 + 资金分配）。"""
    name = str((req or {}).get("name", "")).strip()
    members = (req or {}).get("members") or []
    if not name:
        raise HTTPException(status_code=400, detail="缺少组合名称 name")
    if not members:
        raise HTTPException(status_code=400, detail="members 不能为空")
    for i, m in enumerate(members):
        sid = str(m.get("strategy_id", ""))
        try:
            member = get_strategy(sid)
        except KeyError:
            raise HTTPException(status_code=400, detail=f"成员[{i}] 策略不存在: {sid}")
        if isinstance(member, CompositeStrategy):
            raise HTTPException(status_code=400, detail=f"成员[{i}] 不允许嵌套组合策略: {sid}")
        try:
            if float(m.get("weight", 0)) <= 0:
                raise ValueError
        except (TypeError, ValueError):
            raise HTTPException(status_code=400, detail=f"成员[{i}]（{sid}）weight 须为正数")
    # id 由内容哈希生成：重复提交同一组合幂等覆盖，不堆积重复策略
    sid = "composite_" + hashlib.md5(
        f"{name}|{json.dumps(members, sort_keys=True, ensure_ascii=False)}".encode("utf-8")
    ).hexdigest()[:8]
    try:
        s = save_custom({"id": sid, "name": name, "type": "composite", "members": members})
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return {"ok": True, "id": s.id, "name": s.name}


@app.delete("/api/strategies/custom/{strategy_id}")
def custom_strategies_delete(strategy_id: str) -> OkResponse:
    if not delete_custom(strategy_id):
        raise HTTPException(status_code=404, detail=f"自定义策略 {strategy_id} 不存在")
    return OkResponse(ok=True)


# ---------- 市场状态温度计 ----------

@app.get("/api/regime/status")
def regime_status() -> dict:
    return regime_monitor.status()


@app.post("/api/regime/run")
async def regime_run() -> dict:
    """手动触发一次温度计计算（重活在后台线程，不冻结事件循环）。"""
    try:
        return await asyncio.get_running_loop().run_in_executor(None, regime_monitor.run_once)
    except DataNotReady as exc:
        raise HTTPException(status_code=409, detail=str(exc))
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"温度计计算失败（行情服务不可达？）：{exc}")


# ---------- 盯盘报警 ----------

@app.get("/api/alerts")
def alerts_list() -> list:
    return alert_mgr.list()


@app.post("/api/alerts")
def alerts_add(req: dict = Body(...)) -> dict:
    try:
        return alert_mgr.add(req.get("symbol", ""), req.get("op", ""), float(req.get("price", 0)),
                             note=req.get("note", ""))
    except (ValueError, TypeError) as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@app.delete("/api/alerts/{rule_id}")
def alerts_del(rule_id: int) -> OkResponse:
    if not alert_mgr.remove(rule_id):
        raise HTTPException(status_code=404, detail=f"报警规则 {rule_id} 不存在")
    return OkResponse(ok=True)


# ---------- WebSocket 路由 ----------

@app.websocket("/ws/quotes")
async def ws_quotes(ws: WebSocket) -> None:
    if not _ws_token_ok(ws):
        await ws.close(code=4401)
        return
    await ws.accept()
    await quotes_ws.add(ws)
    # 连接建立立即推一帧，之后由广播任务每秒推送
    await ws.send_json({"type": "quotes", "data": [q.model_dump() for q in quote_engine.snapshot()]})
    try:
        while True:
            await ws.receive_text()  # 忽略客户端消息，仅用于感知断开
    except WebSocketDisconnect:
        pass
    finally:
        quotes_ws.remove(ws)


@app.websocket("/ws/events")
async def ws_events(ws: WebSocket) -> None:
    if not _ws_token_ok(ws):
        await ws.close(code=4401)
        return
    await ws.accept()
    queue = event_bus.subscribe()
    try:
        while True:
            event = await queue.get()
            await ws.send_json(event)
    except WebSocketDisconnect:
        pass
    finally:
        event_bus.unsubscribe(queue)


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("main:app", host="0.0.0.0", port=_core_cfg.get("port", 8700), reload=False)
