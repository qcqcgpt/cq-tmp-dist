"""自动交易信号引擎：策略信号 -> 风控 -> executor 实盘报单，全自动闭环。

工作原理：
- 每个调度周期（默认 60 秒），把当日实时价/量并入日线面板，重算策略目标权重
- 对比实盘账户当前持仓，先卖后买，差额小于阈值不动（避免来回折腾）
- 仅交易时段运行（工作日 09:30-11:30 / 13:00-14:55），其余时间待命
- 科创板(68)买入最低 200 股、步长 1 股；主板 100 股整数倍
- 所有下单动作经 executor 的风控（单票仓位上限 + 单日亏损熔断）

实盘安全约束（P0 审计后加固）：
- 行情陈旧（隧道断）时本轮直接停手，绝不用旧价算账
- 报单前查在途委托：同标的同方向挂单未结，本轮跳过，杜绝重复报单
- 卖出按 T+1 可用数量（can_use_volume），当日买入部分不碰
- 科创板部分减仓后余股不足 200 股时，按规则一次性卖出
- 单票目标仓位钳制到 executor 风控上限，不依赖拒单兜底
- 策略从未产生过信号（数据不足/规格错误）时拒绝任何动作，防止误清仓
- 手动干预保护：识别手动卖出（本期不买回）与手动买入（不擅自卖出），
  保护登记持久化、页面上可解除，避免引擎与用户手工操作互相打架
"""
from __future__ import annotations

import asyncio
import json
import logging
import time as _time
from datetime import datetime, time as dtime
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

import pandas as pd

from datahub import DataHub
from live import ExecutorClient
from strategy import get_strategy

logger = logging.getLogger("autotrade")

# 运行状态落盘：core 重启后据此判断是否为"中断的自动交易"（不自动恢复，仅告警）
STATE_DIR = Path(__file__).resolve().parent.parent / "state"
AUTO_STATE_FILE = STATE_DIR / "autotrade.json"


def load_auto_state() -> Dict[str, Any]:
    """读取 autotrade 持久化状态；文件缺失/损坏时返回空 dict。"""
    try:
        return json.loads(AUTO_STATE_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {}

_TRADE_WINDOWS = [(dtime(9, 30), dtime(11, 30)), (dtime(13, 0), dtime(14, 55))]

# QMT 委托状态码：未终结（在途）状态。终结态：53 部撤 / 54 已撤 / 56 已成 / 57 废单
_OPEN_STATUS = {"48", "49", "50", "51", "52", "55"}
_CLOSED_STATUS = {"53", "54", "56", "57"}


def is_trading_time(now: Optional[datetime] = None) -> bool:
    now = now or datetime.now()
    if now.weekday() >= 5:
        return False
    t = now.time()
    return any(a <= t <= b for a, b in _TRADE_WINDOWS)


def round_lot(symbol: str, qty: float) -> int:
    """A 股买入数量规则：科创板最低 200 股步长 1，主板 100 股整数倍。"""
    qty = int(qty)
    if symbol.startswith(("68", "689")):
        return qty if qty >= 200 else 0
    return (qty // 100) * 100


def _is_star(symbol: str) -> bool:
    """是否科创板（68/689 开头）。"""
    return symbol.startswith(("68", "689"))


def _trading_elapsed_min(now: Optional[datetime] = None) -> int:
    """当日已交易分钟数（用于把盘中累计成交量折算为全日估计）。"""
    now = now or datetime.now()
    t = now.time()
    am_start, am_end = dtime(9, 30), dtime(11, 30)
    pm_start, pm_end = dtime(13, 0), dtime(15, 0)
    if t < am_start:
        return 0
    if t <= am_end:
        return int((datetime.combine(now.date(), t) - datetime.combine(now.date(), am_start)).seconds // 60)
    if t < pm_start:
        return 120
    if t <= pm_end:
        return 120 + int((datetime.combine(now.date(), t) - datetime.combine(now.date(), pm_start)).seconds // 60)
    return 240


class AutoTradeEngine:
    def __init__(self, hub: DataHub, quote_engine, executor: ExecutorClient, event_bus):
        self._hub = hub
        self._qe = quote_engine
        self._exec = executor
        self._bus = event_bus
        self._task: Optional[asyncio.Task] = None
        self._running = False
        self._gen = 0  # 启动代数：stop/start 后旧调度线程据此识别自己已失效
        self._config: Dict[str, Any] = {}
        self._risk: Dict[str, Any] = {}
        self._logs: List[Dict] = []
        self._last_run: Optional[str] = None
        self._last_actions: List[Dict] = []
        # 手动干预保护：对比逐周期持仓快照识别用户手动操作——
        # 手动卖出 -> no_rebuy（本选股周期内不买回）；手动买入 -> no_sell（不擅自减仓/清仓）。
        # 持久化在 autotrade.json，core 重启后仍然有效；页面上可手动解除。
        self._overrides: Dict[str, str] = {}
        self._prev_positions: Dict[str, int] = {}
        self._prev_sold: Set[str] = set()
        self._prev_bought: Set[str] = set()
        self._snapshot_ready = False  # 首个周期只建快照不判定，避免把存量持仓误当手动买入

    # ---------- 状态 ----------

    def status(self) -> Dict:
        return {
            "running": self._running,
            "config": self._config,
            "last_run": self._last_run,
            "last_actions": self._last_actions[-20:],
            "trading_time": is_trading_time(),
            "manual_overrides": dict(self._overrides),
        }

    def logs(self) -> List[Dict]:
        return self._logs[-200:]

    def _log(self, level: str, msg: str, **extra) -> None:
        entry = {"ts": datetime.now().isoformat(timespec="seconds"), "level": level, "msg": msg, **extra}
        self._logs.append(entry)
        getattr(logger, level, logger.info)(msg)
        self._bus.publish({"type": "auto", "data": entry})

    # ---------- 启停 ----------

    def _save_state(self, running: bool) -> None:
        """把当前配置 + running 标记落盘，供 core 重启后识别中断状态。"""
        try:
            STATE_DIR.mkdir(parents=True, exist_ok=True)
            payload = {**self._config, "running": running,
                       "manual_overrides": self._overrides}
            AUTO_STATE_FILE.write_text(json.dumps(payload, ensure_ascii=False, indent=2),
                                       encoding="utf-8")
        except Exception as exc:
            logger.warning("autotrade 状态落盘失败：%s", exc)

    async def start(self, strategy_id: str, params: Dict[str, Any], interval_sec: int = 60,
                    invest_pct: float = 0.95, min_order_value: float = 3000.0,
                    confirm: bool = False) -> None:
        if self._running:
            # 明确拒绝而非静默忽略：调用方（尤其旧标签页/脚本）能立刻知道配置未生效
            raise RuntimeError("自动交易已在运行中，当前配置未变更；如需切换请先停止再启动")
        if not confirm:
            raise ValueError("自动交易将操作真实资金账户，必须显式 confirm=true 确认")
        # 先占位 + 代数递增：健康检查的 await 窗口期内并发的第二个 start 直接返回，
        # 防止起出两个调度循环重复报单；老循环即使尚未退出也会因代数不符不再发单
        self._running = True
        self._gen += 1
        try:
            strategy = get_strategy(strategy_id)
            # 启动即校验实盘链路（同步 HTTP 调用放到线程池，避免冻结事件循环）
            loop = asyncio.get_running_loop()
            await loop.run_in_executor(None, self._exec.health)
            # 启动即校验 executor 风控：未开启则拒绝启动（不拿真实资金裸奔）
            risk = await loop.run_in_executor(None, self._exec.risk_config)
            if not risk.get("enabled", False):
                raise ValueError("executor 端风控未开启，拒绝启动自动交易。请先在「实盘风控」页开启风控。")
        except Exception:
            self._running = False
            raise
        self._risk = risk
        self._config = {
            "strategy_id": strategy_id,
            "params": strategy.resolve_params(params),
            "interval_sec": max(10, int(interval_sec)),
            "invest_pct": min(max(invest_pct, 0.05), 1.0),
            "min_order_value": float(min_order_value),
        }
        self._running = True
        # 恢复上次运行登记的手动干预保护（core 重启不丢）；持仓快照重置，首周期只建快照
        saved_overrides = load_auto_state().get("manual_overrides") or {}
        self._overrides = {str(k): str(v) for k, v in saved_overrides.items()
                           if v in ("no_rebuy", "no_sell")}
        self._prev_positions = {}
        self._prev_sold = set()
        self._prev_bought = set()
        self._snapshot_ready = False
        self._save_state(True)
        if self._overrides:
            self._log("info", "已恢复手动干预保护：" + "、".join(
                f"{sym}({'不再买回' if kind == 'no_rebuy' else '不自动卖出'})"
                for sym, kind in self._overrides.items()))
        self._log("info", f"自动交易已启动：策略 {strategy_id}，周期 {self._config['interval_sec']}s，"
                          f"仓位 {self._config['invest_pct']:.0%}，executor 风控"
                          f"（单票≤{risk.get('max_position_pct', 0):.0%}，日亏≤{risk.get('max_daily_loss', 0):.0%}）")
        self._task = asyncio.create_task(self._loop())

    async def stop(self) -> None:
        self._running = False
        if self._task:
            self._task.cancel()
            self._task = None
        self._save_state(False)
        self._log("info", "自动交易已停止")

    async def shutdown(self) -> None:
        await self.stop()

    # ---------- 手动干预保护 ----------

    def clear_override(self, symbol: Optional[str] = None) -> List[str]:
        """解除手动干预保护：指定标的或全部。返回实际被解除的标的列表。"""
        if symbol:
            removed = [symbol] if self._overrides.pop(symbol, None) is not None else []
        else:
            removed = list(self._overrides)
            self._overrides.clear()
        if removed:
            self._save_state(self._running)
            self._log("info", f"手动干预保护已解除：{'、'.join(removed)}，恢复策略正常管理")
        return removed

    def _detect_manual_ops(self, positions: Dict[str, Dict]) -> None:
        """对比上一周期持仓快照识别手动操作并登记保护（引擎自己报的单不算）。
        首个周期只建快照不判定：否则存量持仓会被误登记成"手动买入"。"""
        if not self._snapshot_ready:
            return
        cur = {s: int(p["qty"]) for s, p in positions.items() if int(p.get("qty", 0)) > 0}
        changed = False
        for sym, prev_qty in self._prev_positions.items():
            cur_qty = cur.get(sym, 0)
            if cur_qty < prev_qty and sym not in self._prev_sold \
                    and self._overrides.get(sym) != "no_rebuy":
                self._overrides[sym] = "no_rebuy"
                changed = True
                self._log("info", f"检测到手动卖出 {sym}：本选股周期内不再自动买回"
                                  f"（策略调出该股后保护自动解除，也可在页面手动解除）")
        for sym, cur_qty in cur.items():
            prev_qty = self._prev_positions.get(sym, 0)
            if cur_qty > prev_qty and sym not in self._prev_bought \
                    and self._overrides.get(sym) != "no_sell":
                self._overrides[sym] = "no_sell"
                changed = True
                self._log("info", f"检测到手动买入 {sym}：不擅自卖出/减仓"
                                  f"（策略正式选入该股后收编管理，也可在页面手动解除）")
        if changed:
            self._save_state(self._running)

    def _refresh_overrides(self, target_w: pd.Series, positions: Dict[str, Dict]) -> None:
        """保护的自动解除：策略调出目标池（no_rebuy）/ 手动仓已不存在或策略正式选入（no_sell）。"""
        if not self._overrides:
            return
        changed = False
        for sym, kind in list(self._overrides.items()):
            w = float(target_w.get(sym, 0.0))
            held = int(positions.get(sym, {}).get("qty", 0)) > 0
            if kind == "no_rebuy" and w <= 0:
                del self._overrides[sym]
                changed = True
                self._log("info", f"{sym} 已被策略调出目标池，手动卖出保护解除")
            elif kind == "no_sell" and not held:
                del self._overrides[sym]
                changed = True
                self._log("info", f"{sym} 手动持仓已不存在，手动买入保护解除")
            elif kind == "no_sell" and w > 0:
                del self._overrides[sym]
                changed = True
                self._log("info", f"{sym} 已被策略选入目标池，收编为策略持仓正常管理")
        if changed:
            self._save_state(self._running)

    # ---------- 主循环 ----------

    def _is_trading_day(self) -> bool:
        """今天是否交易日（法定假日 weekday 判断会误报单）。拉取失败保守按非交易日。"""
        try:
            return self._hub.is_trading_day(datetime.now().date())
        except Exception as exc:
            self._log("warn", f"交易日历查询失败（{exc}），本轮按非交易日处理")
            return False

    async def _loop(self) -> None:
        while self._running:
            try:
                if not is_trading_time():
                    self._log("info", "非交易时段，待命")
                    await asyncio.sleep(30)
                    continue
                if not self._is_trading_day():
                    self._log("info", "今日非交易日（法定节假日或数据源不可用），待命")
                    await asyncio.sleep(30)
                    continue
                await asyncio.get_running_loop().run_in_executor(None, self._rebalance_once)
            except Exception as exc:
                self._log("error", f"调度异常：{exc}")
            await asyncio.sleep(self._config["interval_sec"])

    def _extended_panel(self) -> pd.DataFrame:
        """日线收盘面板 + 当日实时价作为最新一行。"""
        close = self._hub.close_panel().copy()
        today = pd.Timestamp.now().normalize()
        live = {}
        for sym in close.columns:
            px = self._qe.get_price(sym)
            if px:
                live[sym] = px
        if live:
            close.loc[today] = pd.Series(live)
            close = close.ffill()
        return close

    def _extended_volume_panel(self) -> pd.DataFrame:
        """日线成交量面板 + 当日实时量（按已交易时长折算全日估计）作为最新一行。

        不并入当日行会导致量/价面板对齐后当日整行 NaN，含量能因子的策略实盘永不调仓。
        """
        volume = self._hub.volume_panel().copy()
        today = pd.Timestamp.now().normalize()
        elapsed = max(_trading_elapsed_min(), 15)
        scale = min(240.0 / elapsed, 16.0)  # 开盘初期放大失真，封顶 16 倍
        live = {}
        for sym in volume.columns:
            v = self._qe.get_volume(sym)
            if v:
                live[sym] = float(v) * scale
        if live:
            volume.loc[today] = pd.Series(live)
            volume = volume.ffill()
        return volume

    def _open_pairs(self) -> Set[Tuple[str, str]]:
        """在途委托的 (symbol, side) 集合：同标的同方向挂单未结时本轮跳过该方向。"""
        pairs: Set[Tuple[str, str]] = set()
        try:
            for o in self._exec.orders():
                status = str(o.get("status", ""))
                traded = int(o.get("traded_qty", 0) or 0)
                qty = int(o.get("qty", 0) or 0)
                if status in _CLOSED_STATUS:
                    continue
                if status in _OPEN_STATUS or traded < qty:
                    pairs.add((o.get("symbol", ""), str(o.get("side", "")).lower()))
        except Exception as exc:
            self._log("warn", f"查询在途委托失败（{exc}），本轮保守起见全部跳过")
            # 查询失败时返回一个"全阻挡"信号：由调用方识别并停手
            raise
        return pairs

    def _cur_value(self, positions: Dict[str, Dict], sym: str) -> float:
        p = positions.get(sym)
        if not p:
            return 0.0
        px = self._qe.get_price(sym) or 0.0
        return float(p["qty"]) * px

    def _plan_sells(self, target_w, positions: Dict[str, Dict], open_pairs: Set[Tuple[str, str]],
                    total_asset: float, invest: float, min_val: float,
                    overrides: Optional[Dict[str, str]] = None) -> Tuple[List[Dict], List[Tuple[str, str]]]:
        """卖出计划（只算不下单）：不在目标池的清仓，超配的减仓。
        返回 (计划列表, 跳过原因列表)；计划项含估算金额，供执行与预演共用。"""
        plans: List[Dict] = []
        skips: List[Tuple[str, str]] = []
        ov = overrides or {}
        for sym, p in positions.items():
            qty = int(p["qty"])
            if qty <= 0:
                continue
            if ov.get(sym) == "no_sell":
                skips.append((sym, "手动买入保护，不自动卖出"))
                continue
            if (sym, "sell") in open_pairs:
                skips.append((sym, "有在途卖单"))
                continue
            # T+1：可用数量（扣除当日买入）。老版 executor 无该字段时退化为总量
            avail = int(p.get("available", qty))
            tgt_val = float(target_w.get(sym, 0.0)) * total_asset * invest
            diff = self._cur_value(positions, sym) - tgt_val
            if diff <= max(min_val, total_asset * 0.02):
                continue
            px = self._qe.get_price(sym) or float(p["avg_cost"])
            sell_qty = qty if tgt_val <= 0 else min(qty, int(diff / px))
            # 科创板：部分减仓后余股不足 200 股违反规则——留 200 股或清仓
            if _is_star(sym) and tgt_val > 0 and 0 < qty - sell_qty < 200:
                sell_qty = qty - 200
            sell_qty = min(sell_qty, avail)
            # 部分卖出的整手规则（一次性清仓允许零股）：
            # 主板须 100 整数倍、科创板单笔至少 200 股，否则柜台废单并每轮重试
            if 0 < sell_qty < qty:
                if _is_star(sym):
                    if sell_qty < 200:
                        sell_qty = 0
                else:
                    sell_qty = (sell_qty // 100) * 100
            if sell_qty <= 0:
                if avail < qty:
                    skips.append((sym, "持仓含当日买入，可卖数量不足"))
                continue
            plans.append({"symbol": sym, "qty": sell_qty, "price": float(px),
                          "est_value": round(sell_qty * float(px), 2)})
        return plans, skips

    def _plan_buys(self, target_w, positions: Dict[str, Dict], open_pairs: Set[Tuple[str, str]],
                   total_asset: float, cash: float, invest: float, min_val: float,
                   max_pct: float, overrides: Optional[Dict[str, str]] = None) -> Tuple[List[Dict], List[Tuple[str, str]]]:
        """买入计划（只算不下单）：目标池内低配的按权重从高到低补仓，现金依次扣减。"""
        plans: List[Dict] = []
        skips: List[Tuple[str, str]] = []
        ov = overrides or {}
        for sym, w in sorted(target_w.items(), key=lambda kv: -kv[1]):
            if ov.get(sym) == "no_rebuy":
                skips.append((sym, "手动卖出保护，本期不再买回"))
                continue
            if (sym, "buy") in open_pairs:
                skips.append((sym, "有在途买单"))
                continue
            # 单票仓位钳制到 executor 风控上限（权重口径 -> 金额口径）
            w_eff = min(float(w), max_pct / invest) if invest > 0 else float(w)
            tgt_val = w_eff * total_asset * invest
            diff = tgt_val - self._cur_value(positions, sym)
            if diff < max(min_val, total_asset * 0.02):
                continue
            px = self._qe.get_price(sym)
            if not px:
                continue
            buy_val = min(diff, cash)
            qty = round_lot(sym, buy_val / px)
            if qty <= 0:
                continue
            plans.append({"symbol": sym, "qty": qty, "price": float(px),
                          "est_value": round(qty * float(px), 2)})
            cash -= qty * px
        return plans, skips

    def preview(self, strategy_id: str, params: Dict[str, Any],
                invest_pct: float = 0.95, min_order_value: float = 3000.0) -> Dict[str, Any]:
        """切换预演（dry-run）：按给定配置走一遍完整调仓计算，返回预计买卖清单（估算口径）。
        只读行情与账户：绝不下单、不改引擎状态、不写运行日志。"""
        strategy = get_strategy(strategy_id)
        if hasattr(strategy, "set_bars_provider"):
            strategy.set_bars_provider(self._hub.daily_bars)
        close = self._extended_panel()
        volume = self._extended_volume_panel()
        weights_df = strategy.target_weights(close, volume, strategy.resolve_params(params))

        notes: List[str] = []
        # 与实盘一致的防误清仓保护：近期无任何持仓信号时如实告知，不编造动作
        recent = weights_df.tail(10)
        if recent.empty or not bool((recent.sum(axis=1) > 0).any()):
            return {"strategy_id": strategy_id, "no_signal": True,
                    "sells": [], "buys": [], "sell_value": 0.0, "buy_value": 0.0,
                    "notes": ["策略近期未产生任何持仓信号，启动后不会调仓（防误清仓保护）"]}
        if hasattr(self._qe, "is_stale") and self._qe.is_stale():
            notes.append("行情数据当前陈旧（行情链路可能断开），实际调度会停手")
        target_w = weights_df.iloc[-1]
        target_w = target_w[target_w > 0]

        account = self._exec.account()
        positions = {p["symbol"]: p for p in self._exec.positions()}
        total_asset = float(account["total_asset"])
        cash = float(account["cash"])
        invest = min(max(float(invest_pct), 0.05), 1.0)
        min_val = float(min_order_value)
        try:
            max_pct = float((self._exec.risk_config() or {}).get("max_position_pct", 1.0))
        except Exception:
            max_pct = float(self._risk.get("max_position_pct", 0.0)) or 1.0
            notes.append("executor 风控配置拉取失败，单票上限按运行中缓存/100% 估算")
        try:
            open_pairs = self._open_pairs()
        except Exception:
            open_pairs = set()
            notes.append("在途委托查询失败，预演按无在途估算（实际执行会跳过对应方向）")

        sell_plans, sell_skips = self._plan_sells(target_w, positions, open_pairs,
                                                  total_asset, invest, min_val,
                                                  overrides=self._overrides)
        cash_est = cash + sum(sp["est_value"] for sp in sell_plans)
        buy_plans, buy_skips = self._plan_buys(target_w, positions, open_pairs, total_asset,
                                               cash_est, invest, min_val, max_pct,
                                               overrides=self._overrides)
        for sym, reason in sell_skips + buy_skips:
            notes.append(f"{sym} {reason}，将跳过")
        name_of = getattr(self._hub, "name_of", lambda s: s)
        for item in sell_plans + buy_plans:
            item["name"] = name_of(item["symbol"])
        return {
            "strategy_id": strategy_id,
            "no_signal": False,
            "total_asset": round(total_asset, 2),
            "cash": round(cash, 2),
            "invest_pct": invest,
            "sells": sell_plans,
            "buys": buy_plans,
            "sell_value": round(sum(x["est_value"] for x in sell_plans), 2),
            "buy_value": round(sum(x["est_value"] for x in buy_plans), 2),
            "notes": notes,
        }

    def _rebalance_once(self) -> None:
        self._last_run = datetime.now().isoformat(timespec="seconds")
        gen = self._gen  # stop()/二次 start 后，本轮回合视为失效

        # 0) 行情陈旧直接停手：隧道断开时用旧价下单是实盘大忌
        if hasattr(self._qe, "is_stale") and self._qe.is_stale():
            self._log("warn", "行情数据陈旧（隧道断开？），本轮不动作")
            return

        strategy = get_strategy(self._config["strategy_id"])
        if hasattr(strategy, "set_bars_provider"):
            strategy.set_bars_provider(self._hub.daily_bars)  # resonance 需要 OHLC 计算 ATR
        close = self._extended_panel()
        volume = self._extended_volume_panel()
        weights_df = strategy.target_weights(close, volume, self._config["params"])

        # 无信号保护：近 10 行权重全零说明策略从未产出持仓信号
        # （数据不足 / 规格错误），此时对真实持仓的任何动作都可能是误清仓
        recent = weights_df.tail(10)
        if recent.empty or not bool((recent.sum(axis=1) > 0).any()):
            self._log("warn", "策略近期未产生任何持仓信号（数据不足或规格有误），本轮不动作")
            return

        target_w = weights_df.iloc[-1]
        target_w = target_w[target_w > 0]

        account = self._exec.account()
        positions = {p["symbol"]: p for p in self._exec.positions()}
        total_asset = float(account["total_asset"])
        cash = float(account["cash"])
        invest = self._config["invest_pct"]
        min_val = self._config["min_order_value"]
        max_pct = float(self._risk.get("max_position_pct", 1.0))

        # 手动干预识别（须在计划前）：手动卖出 -> 本期不买回；手动买入 -> 不擅自卖出
        self._detect_manual_ops(positions)
        self._refresh_overrides(target_w, positions)

        # 在途委托：同标的同方向挂单未结，本轮不再补报
        open_pairs = self._open_pairs()

        actions: List[Dict] = []

        # 1) 先卖：不在目标池的清仓，超配的减仓
        sell_plans, sell_skips = self._plan_sells(target_w, positions, open_pairs,
                                                  total_asset, invest, min_val,
                                                  overrides=self._overrides)
        for sym, reason in sell_skips:
            self._log("info", f"{sym} {reason}，本轮跳过")
        for plan in sell_plans:
            if not self._running or gen != self._gen:
                return  # stop()/重新 start 后不再发出任何新委托
            r = self._exec.order(plan["symbol"], "sell", plan["qty"])
            actions.append({"side": "sell", "symbol": plan["symbol"], "qty": plan["qty"], "result": r})
            self._log("info", f"卖出 {plan['symbol']} {plan['qty']} 股：{r.get('status')}"
                              + (f"（{r.get('reason')}）" if r.get("reason") else ""))

        # 2) 后买：目标池内低配的补仓（按权重从高到低）
        if actions:  # 卖出回报落地前稍等，释放资金
            _time.sleep(2)
            account = self._exec.account()
            cash = float(account["cash"])

        buy_plans, buy_skips = self._plan_buys(target_w, positions, open_pairs, total_asset,
                                               cash, invest, min_val, max_pct,
                                               overrides=self._overrides)
        for sym, reason in buy_skips:
            self._log("info", f"{sym} {reason}，本轮跳过")
        for plan in buy_plans:
            if not self._running or gen != self._gen:
                return
            r = self._exec.order(plan["symbol"], "buy", plan["qty"])
            actions.append({"side": "buy", "symbol": plan["symbol"], "qty": plan["qty"], "result": r})
            self._log("info", f"买入 {plan['symbol']} {plan['qty']} 股：{r.get('status')}"
                              + (f"（{r.get('reason')}）" if r.get("reason") else ""))

        self._last_actions.extend(actions)
        # 周期末更新持仓快照与本周期引擎报单，供下一周期识别手动干预
        self._prev_positions = {s: int(p["qty"]) for s, p in positions.items()
                                if int(p.get("qty", 0)) > 0}
        self._prev_sold = {a["symbol"] for a in actions if a["side"] == "sell"}
        self._prev_bought = {a["symbol"] for a in actions if a["side"] == "buy"}
        self._snapshot_ready = True
        if not actions:
            self._log("info", "本轮调仓：持仓已贴近目标权重，无操作")
