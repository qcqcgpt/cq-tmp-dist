"""实盘代理：core -> cube-executor（Windows QMT 机器，公网直连，X-Cube-Token 认证）的 HTTP 客户端。

仅用标准库。错误分两类：
- executor 返回了 HTTP 错误（4xx/5xx）：抛 ExecutorHttpError，透传状态码与 detail，
  由路由层按原状态码转发给调用方（业务错误不应伪装成"服务不可达"）
- 网络层失败（连接拒绝/超时）：GET 读接口最多重试 2 次（间隔 1s），
  仍失败则抛 RuntimeError(中文指引)，由路由层转成 502
"""
from __future__ import annotations

import json
import time
import urllib.error
import urllib.parse
import urllib.request
from typing import Dict, List, Optional

GET_RETRIES = 2          # GET 读接口最大重试次数（首次之外的额外尝试）
GET_RETRY_INTERVAL = 1.0  # 重试间隔（秒）

# 云机必须直连：macOS 下 urllib 默认读系统代理（Clash 等），会把到 EIP 的连接劫去
# 本地代理端口导致 ECONNREFUSED。显式空 ProxyHandler 的 opener 无视系统代理。
_opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))


def normalize_symbol(sym: str) -> str:
    """证券代码归一化：6 位数字自动补交易所后缀（QMT 需要 688596.SH 口径）。
    已带后缀或非 6 位数字的输入原样透传。"""
    s = (sym or "").strip().upper()
    if "." in s or not (s.isdigit() and len(s) == 6):
        return s
    if s.startswith(("60", "68", "90")):
        return f"{s}.SH"
    if s.startswith(("00", "30", "20")):
        return f"{s}.SZ"
    if s.startswith(("43", "83", "87", "88", "92")):
        return f"{s}.BJ"
    return s


class ExecutorHttpError(RuntimeError):
    """executor 明确返回的 HTTP 错误（4xx/5xx），透传状态码与 detail。"""

    def __init__(self, status_code: int, detail: str):
        super().__init__(f"executor 返回 HTTP {status_code}：{detail}")
        self.status_code = status_code
        self.detail = detail


class ExecutorClient:
    def __init__(self, base_url: str, timeout: float = 10.0, token: str = ""):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.token = token

    def _once(self, method: str, path: str, body: Optional[dict], params: dict):
        qs = urllib.parse.urlencode(params)
        url = f"{self.base_url}{path}" + (f"?{qs}" if qs else "")
        data = json.dumps(body).encode("utf-8") if body is not None else None
        headers = {"Content-Type": "application/json"}
        if self.token:
            headers["X-Cube-Token"] = self.token
        req = urllib.request.Request(url, data=data, method=method, headers=headers)
        try:
            with _opener.open(req, timeout=self.timeout) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            detail = exc.reason or ""
            try:
                payload = json.loads(exc.read().decode("utf-8"))
                if isinstance(payload, dict):
                    detail = str(payload.get("detail") or payload)
            except Exception:
                pass
            raise ExecutorHttpError(exc.code, detail)

    def _req(self, method: str, path: str, body: Optional[dict] = None, **params):
        attempts = 1 + GET_RETRIES if method == "GET" else 1
        last_exc: Optional[Exception] = None
        for attempt in range(attempts):
            try:
                return self._once(method, path, body, params)
            except ExecutorHttpError:
                raise  # 业务错误不重试、不包装
            except Exception as exc:  # 网络层错误
                last_exc = exc
                if attempt < attempts - 1:
                    time.sleep(GET_RETRY_INTERVAL)
        raise RuntimeError(
            f"实盘执行端不可达（{self.base_url}）。请确认：1) Windows 上 executor 已启动；"
            f"2) 网络可达（公网直连或隧道）。原始错误：{last_exc}"
        )

    # ---- 查询 ----
    def health(self) -> Dict:
        return self._req("GET", "/health")

    def account(self) -> Dict:
        return self._req("GET", "/account")

    def positions(self) -> List[Dict]:
        return self._req("GET", "/positions")

    def orders(self) -> List[Dict]:
        return self._req("GET", "/orders")

    def deals(self) -> List[Dict]:
        return self._req("GET", "/deals")

    def risk_config(self) -> Dict:
        return self._req("GET", "/risk/config")

    # ---- 交易 ----
    def order(self, symbol: str, side: str, qty: int, price_type: str = "market",
              price: Optional[float] = None) -> Dict:
        return self._req("POST", "/order", {
            "symbol": symbol, "side": side, "qty": int(qty),
            "price_type": price_type, "price": price,
        })

    def cancel(self, order_id: str) -> Dict:
        return self._req("POST", "/cancel", order_id=order_id)

    def sell_all(self) -> Dict:
        return self._req("POST", "/sell_all", {})

    def set_risk(self, cfg: Dict) -> Dict:
        return self._req("POST", "/risk/config", cfg)
