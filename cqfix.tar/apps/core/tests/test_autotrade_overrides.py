"""autotrade 手动干预保护单测：识别手动卖出（本期不买回）/ 手动买入（不擅自卖出）、
自动解除条件、持久化恢复；以及 live.normalize_symbol 证券代码归一化。

背景：用户手动卖出持仓后，下一调度周期引擎会因"目标权重>0 而持仓缺失"把股票买回来——
保护机制登记 no_rebuy 豁免；镜像地，手动买入的非目标股登记 no_sell 防止被引擎擅自清仓。
"""
import asyncio
import json

import pandas as pd
import pytest

import autotrade
from autotrade import AutoTradeEngine
from live import normalize_symbol


class FakeQE:
    def get_price(self, sym):
        return 10.0

    def get_volume(self, sym):
        return None

    def is_stale(self):
        return False


class FakeExec:
    def __init__(self, positions):
        self._positions = positions

    def health(self):
        return {"status": "ok"}

    def account(self):
        return {"total_asset": 100000.0, "cash": 50000.0}

    def positions(self):
        return list(self._positions)

    def orders(self):
        return []

    def risk_config(self):
        return {"enabled": True, "max_position_pct": 1.0}

    def order(self, sym, side, qty):
        return {"ok": True, "status": "submitted", "order_id": "T1"}


class FakeHub:
    def name_of(self, sym):
        return sym


class FakeBus:
    def publish(self, msg):
        pass


def make_engine(positions):
    return AutoTradeEngine(FakeHub(), FakeQE(), FakeExec(positions), FakeBus())


def pos_map(positions):
    return {p["symbol"]: p for p in positions}


POS_A = [{"symbol": "A.SH", "qty": 500, "available": 500, "avg_cost": 9.0}]


class TestDetectManualOps:
    def test_first_cycle_only_snapshots(self):
        # 首个周期不判定：否则所有存量持仓都会被误登记为"手动买入"
        eng = make_engine(POS_A)
        eng._detect_manual_ops(pos_map(POS_A))
        assert eng._overrides == {}

    def test_manual_sell_registers_no_rebuy(self):
        eng = make_engine([])
        eng._snapshot_ready = True
        eng._prev_positions = {"A.SH": 500}
        eng._detect_manual_ops({})  # A 消失且引擎没卖过 -> 手动卖出
        assert eng._overrides == {"A.SH": "no_rebuy"}

    def test_manual_partial_sell_registers_no_rebuy(self):
        eng = make_engine(POS_A)
        eng._snapshot_ready = True
        eng._prev_positions = {"A.SH": 1000}
        eng._detect_manual_ops(pos_map(POS_A))  # 1000 -> 500 也算手动减仓
        assert eng._overrides == {"A.SH": "no_rebuy"}

    def test_engine_own_sell_not_registered(self):
        eng = make_engine([])
        eng._snapshot_ready = True
        eng._prev_positions = {"A.SH": 500}
        eng._prev_sold = {"A.SH"}  # 上周期引擎自己卖的
        eng._detect_manual_ops({})
        assert eng._overrides == {}

    def test_manual_buy_registers_no_sell(self):
        eng = make_engine(POS_A)
        eng._snapshot_ready = True
        eng._prev_positions = {}
        eng._detect_manual_ops(pos_map(POS_A))  # 凭空多出的持仓 -> 手动买入
        assert eng._overrides == {"A.SH": "no_sell"}

    def test_engine_own_buy_not_registered(self):
        eng = make_engine(POS_A)
        eng._snapshot_ready = True
        eng._prev_positions = {}
        eng._prev_bought = {"A.SH"}
        eng._detect_manual_ops(pos_map(POS_A))
        assert eng._overrides == {}


class TestOverrideEnforcement:
    def test_no_rebuy_skips_buy_plan(self):
        eng = make_engine([])
        target_w = pd.Series({"A.SH": 0.5})
        plans, skips = eng._plan_buys(target_w, {}, set(), total_asset=100000.0,
                                      cash=100000.0, invest=1.0, min_val=1000.0,
                                      max_pct=1.0, overrides={"A.SH": "no_rebuy"})
        assert plans == []
        assert skips == [("A.SH", "手动卖出保护，本期不再买回")]

    def test_no_sell_skips_sell_plan(self):
        eng = make_engine(POS_A)
        target_w = pd.Series(dtype=float)  # 目标池为空，本应清仓
        plans, skips = eng._plan_sells(target_w, pos_map(POS_A), set(),
                                       total_asset=100000.0, invest=1.0, min_val=1000.0,
                                       overrides={"A.SH": "no_sell"})
        assert plans == []
        assert skips == [("A.SH", "手动买入保护，不自动卖出")]

    def test_unrelated_symbol_unaffected(self):
        eng = make_engine(POS_A)
        target_w = pd.Series(dtype=float)
        plans, _ = eng._plan_sells(target_w, pos_map(POS_A), set(),
                                   total_asset=100000.0, invest=1.0, min_val=1000.0,
                                   overrides={"B.SH": "no_sell"})
        assert plans[0]["symbol"] == "A.SH"  # B 的保护不影响 A 正常清仓


class TestRefreshOverrides:
    def test_no_rebuy_cleared_when_rotated_out(self):
        eng = make_engine([])
        eng._overrides = {"A.SH": "no_rebuy"}
        eng._refresh_overrides(pd.Series(dtype=float), {})
        assert eng._overrides == {}

    def test_no_rebuy_kept_while_in_target(self):
        eng = make_engine([])
        eng._overrides = {"A.SH": "no_rebuy"}
        eng._refresh_overrides(pd.Series({"A.SH": 0.2}), {})
        assert eng._overrides == {"A.SH": "no_rebuy"}

    def test_no_sell_cleared_when_position_gone(self):
        eng = make_engine([])
        eng._overrides = {"A.SH": "no_sell"}
        eng._refresh_overrides(pd.Series(dtype=float), {})
        assert eng._overrides == {}

    def test_no_sell_adopted_when_strategy_selects(self):
        eng = make_engine(POS_A)
        eng._overrides = {"A.SH": "no_sell"}
        eng._refresh_overrides(pd.Series({"A.SH": 0.2}), pos_map(POS_A))
        assert eng._overrides == {}

    def test_no_sell_kept_while_off_target_and_held(self):
        eng = make_engine(POS_A)
        eng._overrides = {"A.SH": "no_sell"}
        eng._refresh_overrides(pd.Series(dtype=float), pos_map(POS_A))
        assert eng._overrides == {"A.SH": "no_sell"}


class TestClearOverride:
    def test_clear_single(self):
        eng = make_engine([])
        eng._overrides = {"A.SH": "no_rebuy", "B.SH": "no_sell"}
        assert eng.clear_override("A.SH") == ["A.SH"]
        assert eng._overrides == {"B.SH": "no_sell"}

    def test_clear_all(self):
        eng = make_engine([])
        eng._overrides = {"A.SH": "no_rebuy", "B.SH": "no_sell"}
        assert sorted(eng.clear_override()) == ["A.SH", "B.SH"]
        assert eng._overrides == {}

    def test_clear_unknown_is_noop(self):
        eng = make_engine([])
        eng._overrides = {"A.SH": "no_rebuy"}
        assert eng.clear_override("ZZ.SH") == []
        assert eng._overrides == {"A.SH": "no_rebuy"}


class TestPersistence:
    def test_state_roundtrip_and_start_restores(self, tmp_path, monkeypatch):
        state_file = tmp_path / "autotrade.json"
        monkeypatch.setattr(autotrade, "STATE_DIR", tmp_path)
        monkeypatch.setattr(autotrade, "AUTO_STATE_FILE", state_file)
        # 预置一份"中断的自动交易"状态，含手动干预保护
        state_file.write_text(json.dumps({
            "strategy_id": "ai_momentum_top", "params": {}, "running": True,
            "manual_overrides": {"A.SH": "no_rebuy", "B.SH": "bogus"},
        }), encoding="utf-8")

        eng = make_engine(POS_A)

        async def run():
            await eng.start("ai_momentum_top", {"top_n": 3}, interval_sec=60,
                            invest_pct=0.9, min_order_value=3000.0, confirm=True)
            await eng.stop()

        asyncio.run(run())
        # 合法保护被恢复，非法值被过滤；落盘文件中保留
        assert eng._overrides == {"A.SH": "no_rebuy"}
        saved = json.loads(state_file.read_text(encoding="utf-8"))
        assert saved["manual_overrides"] == {"A.SH": "no_rebuy"}


class TestNormalizeSymbol:
    @pytest.mark.parametrize("raw,expected", [
        ("688596", "688596.SH"),
        ("600519", "600519.SH"),
        ("000001", "000001.SZ"),
        ("300750", "300750.SZ"),
        ("688596.SH", "688596.SH"),   # 已带后缀原样
        ("688596.sh", "688596.SH"),   # 小写后缀归一
        (" 600519 ", "600519.SH"),    # 空白裁剪
        ("920001", "920001.BJ"),      # 北交所
        ("ABC", "ABC"),               # 非数字原样透传
        ("12345", "12345"),           # 非 6 位原样透传
    ])
    def test_normalize(self, raw, expected):
        assert normalize_symbol(raw) == expected
