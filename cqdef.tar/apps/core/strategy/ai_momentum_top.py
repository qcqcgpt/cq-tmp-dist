"""内置策略 ai_momentum_top：AI 动量优选（Regime 动态版）。

四因子复合打分（截面 z-score 加权）：动量 + 波动率（负向）+ 均线乖离 + 稳定性
（Kaufman 效率系数：|N日净涨跌| / Σ|日涨跌|，趋势越平滑得分越高）。

大盘 Regime 驱动仓位与调仓节奏（沪深300 指数，000300.SH）：
- Regime 分数 = 0.45×ADX趋势强度 + 0.35×均线多空排列 + 0.20×波动率分位（低波高分），0~1
- 分数 ≥ 趋势市阈值：仓位 100%，每 rebalance_trending 个交易日换股
- 过渡区：仓位 50%~100% 线性，每 rebalance_transition 日换股
- < 震荡市阈值：仓位 0%~50% 线性，每 rebalance_ranging 日换股
仓位比例每日随 Regime 分数调整（风控由仓位层承担）；换股只在间隔期满时发生。

双重防御（use_defense 总开关）：
- Regime 清仓线：score < def_regime_flat（默认 0.40）直接空仓——震荡负期望环境不交易
- 权益 DD 熔断：组合净值自历史峰值回撤超 def_dd_warn（6%）线性减仓、
  超 def_dd_flat（12%）清仓；按未熔断净值度量，企稳后自动恢复

指数数据经 bars_provider("000300.SH") 按需拉取；拿不到时退化为观察池等权代理
（高低价缺失时 ADX 退化为 0），回测/测试无指数源也能跑。
"""
from __future__ import annotations

from typing import Any, Dict, Optional

import numpy as np
import pandas as pd
from protocol import ParamSpec

from .base import Strategy

INDEX_SYMBOL = "000300.SH"  # 沪深300：Regime 检测基准


def _zscore(df: pd.DataFrame) -> pd.DataFrame:
    """截面（按行）z-score 标准化；当日截面方差为 0 时填 0。"""
    mean = df.mean(axis=1)
    std = df.std(axis=1).replace(0, np.nan)
    return df.sub(mean, axis=0).div(std, axis=0).fillna(0.0)


class AiMomentumTopStrategy(Strategy):
    id = "ai_momentum_top"
    name = "AI 动量优选"
    description = (
        "四因子打分（动量/波动惩罚/乖离/稳定性）选取 Top N 等权持有；"
        "沪深300 Regime 分数（ADX+均线排列+波动率分位）动态决定仓位比例与调仓间隔；"
        "双重防御：Regime 清仓线 + 权益 DD 熔断（总开关可控）。"
    )
    params_schema = [
        ParamSpec(key="top_n", label="持仓只数", type="int", default=8, min=2, max=15),
        ParamSpec(key="lookback", label="动量回看(日)", type="int", default=20, min=5, max=60),
        ParamSpec(key="w_mom", label="动量权重", type="float", default=0.8, min=0.0, max=2.0),
        ParamSpec(key="w_vol", label="波动率权重(负向)", type="float", default=-0.6, min=-2.0, max=0.0),
        ParamSpec(key="w_bias", label="乖离权重", type="float", default=0.2, min=0.0, max=1.0),
        ParamSpec(key="w_stability", label="稳定性权重", type="float", default=0.4, min=0.0, max=1.0),
        ParamSpec(key="adx_period", label="ADX周期(日)", type="int", default=14, min=5, max=30),
        ParamSpec(key="ma_short", label="短期均线(日)", type="int", default=20, min=5, max=60),
        ParamSpec(key="ma_long", label="长期均线(日)", type="int", default=60, min=20, max=250),
        ParamSpec(key="vol_window", label="波动率窗口(日)", type="int", default=60, min=20, max=120),
        ParamSpec(key="vol_lookback", label="波动率分位回看(日)", type="int", default=200, min=60, max=500),
        ParamSpec(key="trend_th", label="趋势市阈值", type="float", default=0.55, min=0.3, max=0.8),
        ParamSpec(key="range_th", label="震荡市阈值", type="float", default=0.45, min=0.2, max=0.6),
        ParamSpec(key="rebalance_trending", label="趋势市调仓(交易日)", type="int", default=10, min=1, max=30),
        ParamSpec(key="rebalance_transition", label="过渡区调仓(交易日)", type="int", default=5, min=1, max=30),
        ParamSpec(key="rebalance_ranging", label="震荡市调仓(交易日)", type="int", default=3, min=1, max=30),
        ParamSpec(key="use_defense", label="防御机制总开关(1开/0关)", type="int", default=1, min=0, max=1),
        ParamSpec(key="def_regime_flat", label="Regime清仓阈值", type="float", default=0.40, min=0.35, max=0.45,
                  depends_on="use_defense"),
        ParamSpec(key="def_dd_warn", label="权益DD警告线(比例)", type="float", default=0.06, min=0.04, max=0.12,
                  depends_on="use_defense"),
        ParamSpec(key="def_dd_flat", label="权益DD熔断线(比例)", type="float", default=0.12, min=0.08, max=0.25,
                  depends_on="use_defense"),
    ]

    def __init__(self):
        self._bars_provider = None

    def set_bars_provider(self, fn) -> None:
        """注入日线来源（hub.daily_bars）：按需拉取沪深300 指数 OHLC 做 Regime 检测。"""
        self._bars_provider = fn

    # ---------- 打分 ----------

    def composite_score(self, close: pd.DataFrame, params: Optional[Dict[str, Any]] = None) -> pd.DataFrame:
        """四因子复合打分：w_mom×动量 + w_vol×波动率 + w_bias×乖离 + w_stability×稳定性。"""
        p = self.resolve_params(params or {})
        n = int(p["lookback"])
        mom = close.pct_change(n)
        vol = close.pct_change().rolling(n).std()
        bias = close / close.rolling(n).mean() - 1.0
        # 稳定性（Kaufman 效率系数）：|N日净涨跌| / Σ|日涨跌|，0~1，趋势越平滑越高
        net = (close - close.shift(n)).abs()
        path = close.diff().abs().rolling(n).sum()
        er = net / path.replace(0, np.nan)
        score = (float(p["w_mom"]) * _zscore(mom)
                 + float(p["w_vol"]) * _zscore(vol)
                 + float(p["w_bias"]) * _zscore(bias)
                 + float(p["w_stability"]) * _zscore(er.fillna(0.0)))
        # 前 lookback 个交易日为因子 warmup 期，打分为 NaN，不得参与选股
        return score.where(mom.notna())

    # ---------- Regime 检测 ----------

    @staticmethod
    def _adx(high: pd.Series, low: pd.Series, close: pd.Series, period: int) -> pd.Series:
        """Wilder ADX：趋势强度 0~100，越高趋势越强（方向无关）。"""
        up = high.diff()
        down = -low.diff()
        plus_dm = pd.Series(np.where((up > down) & (up > 0), up, 0.0), index=high.index)
        minus_dm = pd.Series(np.where((down > up) & (down > 0), down, 0.0), index=high.index)
        tr = pd.concat([high - low, (high - close.shift(1)).abs(),
                        (low - close.shift(1)).abs()], axis=1).max(axis=1)
        atr = tr.ewm(alpha=1.0 / period, min_periods=period).mean()
        plus_di = 100.0 * plus_dm.ewm(alpha=1.0 / period, min_periods=period).mean() / atr
        minus_di = 100.0 * minus_dm.ewm(alpha=1.0 / period, min_periods=period).mean() / atr
        dx = 100.0 * (plus_di - minus_di).abs() / (plus_di + minus_di).replace(0, np.nan)
        return dx.ewm(alpha=1.0 / period, min_periods=period).mean()

    def _index_ohlc(self, index: pd.DatetimeIndex) -> Optional[pd.DataFrame]:
        """沪深300 指数 OHLC（按面板交易日对齐、前向填充）；拿不到返回 None。"""
        if self._bars_provider is None:
            return None
        try:
            df = self._bars_provider(INDEX_SYMBOL)
            if df is None or len(df) < 30:
                return None
            return df[["open", "high", "low", "close"]].reindex(index).ffill()
        except Exception:
            return None

    def regime_score(self, close: pd.DataFrame, p: Dict[str, Any]) -> pd.Series:
        """Regime 分数序列（0~1）：0.45×ADX + 0.35×均线排列 + 0.20×波动率分位。
        指数不可用/数据不足时退化（ADX=0、分位=0.5），预热期填中性 0.5。"""
        idx = close.index
        ohlc = self._index_ohlc(idx)
        if ohlc is not None and ohlc["close"].notna().sum() >= int(p["ma_long"]):
            ic, ih, il = ohlc["close"], ohlc["high"], ohlc["low"]
            adx_norm = (self._adx(ih, il, ic, int(p["adx_period"])) / 50.0).clip(0.0, 1.0)
        else:
            # 退化：观察池等权代理，无高低价 → ADX 计 0（趋势强度信息缺失，保守）
            ic = close.mean(axis=1)
            adx_norm = pd.Series(0.0, index=idx)
        # 均线多空排列：完全多头 1.0 / 完全空头 0.0 / 部分对齐 0.5
        ma_s = ic.rolling(int(p["ma_short"])).mean()
        ma_l = ic.rolling(int(p["ma_long"])).mean()
        align = ((ic > ma_s).astype(float) + (ma_s > ma_l).astype(float)) / 2.0
        # 波动率分位：当前 vol_window 日波动在 vol_lookback 日窗口中的分位；低波动 → 高分
        vol = ic.pct_change().rolling(int(p["vol_window"])).std()
        mp = max(20, int(p["vol_lookback"]) // 4)
        pct = vol.rolling(int(p["vol_lookback"]), min_periods=mp).rank(pct=True)
        vol_score = (1.0 - pct).clip(0.0, 1.0)
        score = 0.45 * adx_norm + 0.35 * align + 0.20 * vol_score
        return score.clip(0.0, 1.0).fillna(0.5)

    @staticmethod
    def position_ratio(score: pd.Series, p: Dict[str, Any]) -> pd.Series:
        """Regime 分数 → 仓位比例：趋势市 100%，过渡区 50~100% 线性，震荡市 0~50% 线性。"""
        th_t, th_r = float(p["trend_th"]), float(p["range_th"])
        transition = 0.5 + (score - th_r) / (th_t - th_r) * 0.5
        ranging = score / th_r * 0.5
        out = ranging.where(score < th_r, transition)  # [th_r, th_t)：过渡区线性
        out = out.where(score < th_t, 1.0)             # ≥ th_t：满仓
        return out.clip(0.0, 1.0)

    @staticmethod
    def rebalance_interval(score: pd.Series, p: Dict[str, Any]) -> pd.Series:
        """Regime 分数 → 调仓间隔（交易日）：趋势市/过渡区/震荡市三档。"""
        out = pd.Series(int(p["rebalance_ranging"]), index=score.index)
        out = out.where(score < float(p["range_th"]), int(p["rebalance_transition"]))
        out = out.where(score < float(p["trend_th"]), int(p["rebalance_trending"]))
        return out

    # ---------- 权重 ----------

    def _base_weights(self, close: pd.DataFrame, p: Dict[str, Any]) -> pd.DataFrame:
        """打分换股（间隔由 Regime 决定）× 仓位比例（每日随 Regime 调整）× 双重防御。

        防御层（use_defense 总开关）：
        - 第一层 Regime 清仓线：score < def_regime_flat 时仓位直接归零（震荡负期望环境不交易）
        - 第二层 权益 DD 熔断：组合净值（Regime 仓位口径）自历史峰值回撤超 def_dd_warn
          线性减仓、超 def_dd_flat 清零。按未熔断净值度量——熔断期间净值仍在跟踪，
          企稳回到警告线内自动恢复（不会因空仓冻结而永久锁死）。
        """
        top_n = int(p["top_n"])
        score = self.composite_score(close, p)
        regime = self.regime_score(close, p)
        pos = self.position_ratio(regime, p)
        interval = self.rebalance_interval(regime, p)
        use_def = int(p.get("use_defense", 1))
        def_flat = float(p.get("def_regime_flat", 0.40))
        dd_warn = float(p.get("def_dd_warn", 0.06))
        dd_kill = max(float(p.get("def_dd_flat", 0.12)), dd_warn + 0.01)
        if use_def:  # 第一层：Regime 清仓线
            pos = pos.where(regime >= def_flat, 0.0)

        ret = close.pct_change().fillna(0.0)
        weights = pd.DataFrame(0.0, index=close.index, columns=close.columns)
        current = pd.Series(0.0, index=close.columns)
        prev_risk_w = pd.Series(0.0, index=close.columns)  # 熔断度量持仓（不含熔断缩放）
        eq, peak = 1.0, 1.0
        since_rebalance = 10 ** 9  # 保证首个有效交易日立即建仓
        for dt in close.index:
            row = score.loc[dt].dropna()
            since_rebalance += 1
            if len(row) >= top_n and since_rebalance >= int(interval.loc[dt]):
                top = row.nlargest(top_n).index
                current = pd.Series(0.0, index=close.columns)
                current.loc[top] = 1.0 / top_n
                since_rebalance = 0
            risk_w = current * float(pos.loc[dt])
            dd_scale = 1.0
            if use_def:  # 第二层：权益 DD 熔断
                eq *= 1.0 + float((prev_risk_w * ret.loc[dt]).sum())
                peak = max(peak, eq)
                dd = eq / peak - 1.0
                if dd <= -dd_kill:
                    dd_scale = 0.0
                elif dd <= -dd_warn:
                    dd_scale = 1.0 - (abs(dd) - dd_warn) / (dd_kill - dd_warn)
            weights.loc[dt] = risk_w * dd_scale
            prev_risk_w = risk_w
        return weights

    def target_weights(self, close: pd.DataFrame, volume: pd.DataFrame, params: Dict[str, Any]) -> pd.DataFrame:
        p = self.resolve_params(params)
        # 当日实时行（autotrade 扩展面板）不参与因子/Regime 计算，沿用前一交易日决策
        # （T+1 语义），否则盘中价会改变选股并使调仓节奏前移
        today = pd.Timestamp.now().normalize()
        has_live_row = len(close.index) > 0 and close.index[-1] == today
        daily = close.iloc[:-1] if has_live_row else close
        out = self._base_weights(daily, p)
        if has_live_row and len(out.index):  # 实盘当日行 = 前一交易日收盘后的目标
            out.loc[today] = out.iloc[-1]
        return out

    def screen_rows(self, close: pd.DataFrame, volume: pd.DataFrame,
                    params: Dict[str, Any]) -> List[Dict[str, Any]]:
        """选股器：按四因子复合分排序，持仓只打标不置顶——
        用户要看的是全池里的新机会，持仓霸榜会把它们埋在下面。"""
        score = self.composite_score(close, params)
        if score.empty:
            return []
        last = score.iloc[-1]
        w = self.target_weights(close, volume, params)
        selected = set(w.columns[w.iloc[-1] > 0]) if not w.empty else set()
        rows = [{"symbol": s,
                 "selected": s in selected,
                 "score": round(float(last[s]), 4) if pd.notna(last[s]) else None}
                for s in score.columns]
        rows.sort(key=lambda r: -(r["score"] if r["score"] is not None else -999))
        return rows
